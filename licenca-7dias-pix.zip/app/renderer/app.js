'use strict';

const $ = (id) => document.getElementById(id);

const state = {
	activeProjectId: null,
	activeChatUuid: null,
	projects: [],
	chats: [],
	chat: null,
	running: false,
	stats: null,
	chatWindowVisible: true,
	activeAssistantBlock: null,
	booted: false,
	histPage: 0,
	histTotal: 0,
	commitsOpen: false,
};

const TOKENS_WARN = 12000;
const TOKENS_DANGER = 20000;
const TASKS_WARN = 5;
const TASKS_DANGER = 10;

let creatingProject = false;
let pendingCommands = new Map();
let pendingRunBatch = null;
let pendingDelete = null;
let modalProjectMode = 'create';
let editingProjectId = null;

let overlayTimer = null;
let overlayRetryFn = null;

let pendingRestore = null;
let pendingMerge = null;
let diffState = null;
let diffToken = 0;

function fmtNum(n) { return (n || 0).toLocaleString('pt-BR'); }
function timeNow() {
	return new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
function fmtDate(ts) {
	if (!ts) return '';
	const d = new Date(ts);
	const today = new Date();
	if (d.toDateString() === today.toDateString()) {
		return 'Hoje · ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
	}
	return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' · ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
function escapeHtml(s) {
	return String(s == null ? '' : s)
		.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function stripProtocol(msg) {
	if (typeof msg !== 'string') return '';
	let s = msg;
	s = s.replace(/^<<<RESULT:[^>]*>>>\s*/i, '');
	s = s.replace(/\s*<<<END>>>\s*$/i, '');
	s = s.replace(/<<<END>>>/gi, '');
	return s.trim();
}

function showDiag(msg, ok, opts) {
	opts = opts || {};
	const b = $('diag-banner');
	b.style.display = 'flex';
	b.style.alignItems = 'center';
	b.style.gap = '10px';
	b.style.pointerEvents = 'auto';
	b.style.zIndex = '25000';
	b.style.background = ok ? '#14532d' : '#7f1d1d';
	b.style.color = ok ? '#bbf7d0' : '#fecaca';
	b.style.border = '1px solid ' + (ok ? '#15803d' : '#991b1b');
	b.innerHTML = '';

	const txt = document.createElement('span');
	txt.style.flex = '1';
	txt.textContent = msg;
	b.appendChild(txt);

	if (opts.actionLabel && typeof opts.onAction === 'function') {
		const btn = document.createElement('button');
		btn.type = 'button';
		btn.textContent = opts.actionLabel;
		btn.style.cssText = 'padding:4px 10px;border-radius:6px;border:1px solid rgba(255,255,255,.4);background:rgba(255,255,255,.15);color:#fff;font-size:11px;font-weight:700;cursor:pointer;flex-shrink:0';
		btn.addEventListener('click', () => {
			b.style.display = 'none';
			try { opts.onAction(); } catch (e) { }
		});
		b.appendChild(btn);
	}

	clearTimeout(b._t);
	b._t = setTimeout(() => { b.style.display = 'none'; }, opts.duration || 8000);
}

function clearPendingTimers() {
	for (const [, entry] of pendingCommands) {
		clearTimeout(entry.timer);
		const ecard = entry.card && entry.card.querySelector('.event-card');
		if (ecard && ecard.classList.contains('is-pending')) {
			ecard.classList.remove('is-pending');
			ecard.classList.add('is-cancel');
			const desc = ecard.querySelector('.event-desc');
			if (desc) desc.textContent = 'Interrompido (sem resultado)';
		}
	}
	pendingCommands.clear();
}

function showOverlay(title, caption) {
	if (overlayTimer) { clearTimeout(overlayTimer); overlayTimer = null; }
	$('overlayTitle').textContent = title || 'Aguarde…';
	$('overlayCaption').textContent = caption || '';
	$('overlaySpinner').style.display = '';
	$('overlayActions').style.display = 'none';
	overlayRetryFn = null;
	$('overlay').style.display = 'flex';
}

function showOverlayDelayed(title, caption, delayMs) {
	if ($('overlay').style.display === 'flex') {
		$('overlayTitle').textContent = title || 'Aguarde…';
		$('overlayCaption').textContent = caption || '';
		return;
	}
	if (overlayTimer) clearTimeout(overlayTimer);
	overlayTimer = setTimeout(() => {
		overlayTimer = null;
		showOverlay(title, caption);
	}, delayMs || 300);
}

function hideOverlay() {
	if (overlayTimer) { clearTimeout(overlayTimer); overlayTimer = null; }
	$('overlay').style.display = 'none';
	overlayRetryFn = null;
}

function overlayError(msg, retryFn) {
	if (overlayTimer) { clearTimeout(overlayTimer); overlayTimer = null; }
	$('overlay').style.display = 'flex';
	$('overlaySpinner').style.display = 'none';
	$('overlayTitle').textContent = 'Algo deu errado';
	$('overlayCaption').textContent = msg || 'Falha inesperada.';
	$('overlayActions').style.display = 'flex';
	overlayRetryFn = retryFn || null;
}

$('overlayRetry').addEventListener('click', () => {
	const fn = overlayRetryFn;
	hideOverlay();
	if (typeof fn === 'function') {
		try { fn(); } catch (e) { showDiag('Erro: ' + e.message, false); }
	}
});

$('overlayCancel').addEventListener('click', () => { hideOverlay(); });

function hideBootCover() {
	const c = $('bootCover');
	c.classList.add('hidden');
	setTimeout(() => { c.style.display = 'none'; }, 350);
}

async function boot() {
	if (state.booted) return;
	state.booted = true;
	try {
		const st = await window.projectsAPI.state();
		applyState(st);
		try { await restoreHistory(); } catch (e) { }
	} catch (e) { showDiag('Falha ao carregar projetos: ' + e.message, false); }
	try {
		const v = await window.agentAPI.isChatVisible();
		applyChatWindowState(v);
	} catch (e) { }
	try {
		const s = await window.agentAPI.stats();
		applyStats(s);
	} catch (e) { }
}

window.appAPI.onReady((data) => {
	hideBootCover();
	if (data && data.ok) boot();
	else showDiag('Boot reportou erro: ' + (data && data.error ? data.error : 'desconhecido'), false);
});

setTimeout(() => {
	if (!state.booted) { hideBootCover(); boot(); }
}, 30000);

async function refreshGitBanner() {
	const b = $('gitBanner');
	const msg = $('gitBannerMsg');
	const btn = $('gitBannerBtn');
	if (!b || !msg || !btn) return;
	const project = state.projects.find(p => p.id === state.activeProjectId);
	if (!project || !project.projectRoot || !project.slug) { b.style.display = 'none'; return; }
	let st = null;
	try { st = await window.agentAPI.gitStatus(project.projectRoot, project.slug); } catch (e) { st = null; }
	if (project.id !== state.activeProjectId) return;
	if (!st) { b.style.display = 'none'; return; }
	btn.style.display = 'none';
	if (st.state === 'nogit') {
		msg.textContent = '⚠️ Esta pasta não tem Git: nada protege seus arquivos contra alterações do agente.';
	} else if (st.state === 'nogitbin') {
		msg.textContent = '⚠️ Git não encontrado no sistema (PATH): sem proteção de branch.';
	} else if (st.state === 'nobranch') {
		msg.textContent = '⚠️ A branch "' + st.expected + '" não existe. Você está em "' + (st.current || '?') + '".';
		btn.style.display = '';
	} else if (st.state === 'wrongbranch') {
		msg.textContent = '⚠️ Você está na branch "' + st.current + '" (esperada: "' + st.expected + '").';
	} else {
		b.style.display = 'none';
		return;
	}
	b.style.display = 'flex';
}

function fmtCommitDate(ts) {
	const d = new Date(ts);
	return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) + ' · ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function setCommitsOpen(open) {
	state.commitsOpen = !!open;
	const panel = $('commitsPanel');
	const appEl = document.querySelector('.app');
	if (panel) panel.style.display = state.commitsOpen ? 'flex' : 'none';
	if (appEl) appEl.classList.toggle('commits-open', state.commitsOpen);
	if (state.commitsOpen) refreshCommitsPanel();
}

function commitsMsg(list, text) {
	list.innerHTML = '';
	const em = document.createElement('div');
	em.className = 'commits-empty';
	em.textContent = text;
	list.appendChild(em);
}

async function refreshCommitsPanel() {
	if (!state.commitsOpen) return;
	const list = $('commitsList');
	const sub = $('commitsSub');
	if (!list || !sub) return;
	const project = state.projects.find(p => p.id === state.activeProjectId);
	if (!project || !project.projectRoot || !project.slug) {
		sub.textContent = '—';
		commitsMsg(list, 'Selecione um projeto com pasta raiz.');
		return;
	}
	let r = null;
	try { r = await window.agentAPI.gitLog(project.projectRoot, project.slug, 50); }
	catch (e) { r = { ok: false, error: e.message }; }
	if (project.id !== state.activeProjectId || !state.commitsOpen) return;
	if (!r || !r.ok) {
		sub.textContent = '—';
		commitsMsg(list, (r && r.error) || 'Não foi possível listar os commits.');
		return;
	}
	sub.textContent = r.branch + ' · ' + r.commits.length + ' commit(s)';
	if (!r.commits.length) { commitsMsg(list, 'Nenhum commit nesta branch.'); return; }
	list.innerHTML = '';
	const mk = function (tag, cls, text) {
		const el = document.createElement(tag);
		if (cls) el.className = cls;
		if (text !== undefined) el.textContent = text;
		return el;
	};
	r.commits.forEach(function (c, idx) {
		const btn = mk('button', 'commit-item' + (c.isRestore ? ' is-restore' : '') + (idx === 0 ? ' is-head' : ''));
		btn.type = 'button';
		const subj = mk('div', 'commit-subject', c.isRestore ? '↩ Restore para ' + c.restoreOf : c.subject);
		subj.title = c.subject;
		const meta = mk('div', 'commit-meta');
		if (idx === 0) meta.appendChild(mk('span', 'commit-badge', 'ATUAL'));
		meta.appendChild(mk('span', 'commit-hash', c.short));
		meta.appendChild(mk('span', '', fmtCommitDate(c.ts)));
		meta.appendChild(mk('span', '', c.files + (c.files === 1 ? ' arquivo' : ' arquivos')));
		if (c.insertions) meta.appendChild(mk('span', 'commit-add', '+' + c.insertions));
		if (c.deletions) meta.appendChild(mk('span', 'commit-del', '-' + c.deletions));
		btn.appendChild(subj);
		btn.appendChild(meta);
		btn.addEventListener('click', () => {
			openDiffModal(project, c, idx === 0, r.dirty || 0);
		});
		list.appendChild(btn);
	});
}

function openRestoreModal(project, c, dirty) {
	if (state.running) { showDiag('Aguarde a tarefa terminar para restaurar.', false); return; }
	pendingRestore = { project: project, commit: c };
	$('modalRestoreCaption').textContent = 'Os arquivos do projeto voltarão ao estado deste commit. O histórico é preservado: será criado um novo commit de restore.';
	const info = $('modalRestoreInfo');
	info.className = 'restore-info';
	info.innerHTML = '';
	const t = document.createElement('div');
	t.style.fontWeight = '600';
	t.textContent = c.isRestore ? '↩ Restore para ' + c.restoreOf : c.subject;
	const m = document.createElement('div');
	m.style.color = '#96a6bc';
	m.textContent = c.short + ' · ' + fmtCommitDate(c.ts) + ' · ' + c.files + (c.files === 1 ? ' arquivo' : ' arquivos');
	info.appendChild(t);
	info.appendChild(m);
	const warn = $('modalRestoreWarn');
	warn.className = 'restore-warn';
	if (dirty > 0) {
		warn.textContent = 'Atenção: ' + dirty + ' arquivo(s) com alterações não commitadas serão sobrescritos e perdidos.';
		warn.style.display = 'block';
	} else {
		warn.style.display = 'none';
	}
	$('modalRestore').style.display = 'flex';
}

async function openMergeModal() {
	if (state.running) { showDiag('Aguarde a tarefa terminar para aplicar o merge.', false); return; }
	const project = state.projects.find(p => p.id === state.activeProjectId);
	if (!project || !project.projectRoot || !project.slug) { showDiag('Selecione um projeto com pasta raiz.', false); return; }
	let r = null;
	try { r = await window.agentAPI.gitBranches(project.projectRoot, project.slug); }
	catch (e) { r = { ok: false, error: e.message }; }
	if (!r || !r.ok) { showDiag('Falha ao listar as branches: ' + ((r && r.error) || 'erro desconhecido'), false); return; }
	if (!r.branches.length) { showDiag('Não há outra branch para receber o merge.', false); return; }
	pendingMerge = { project: project, agent: r.agent };
	$('modalMergeCaption').textContent = 'Todas as alterações da branch "' + r.agent + '" serão aplicadas em 1 único commit (squash) na branch escolhida. Depois, a branch do agente volta a ficar igual ao destino e a lista de commits recomeça.';
	const sel = $('modalMergeSelect');
	sel.innerHTML = '';
	r.branches.forEach(function (b) {
		const o = document.createElement('option');
		o.value = b;
		o.textContent = b;
		sel.appendChild(o);
	});
	$('modalMerge').style.display = 'flex';
}

function diffPathParts(p) {
	const norm = String(p || '').replace(/\\/g, '/');
	const idx = norm.lastIndexOf('/');
	if (idx === -1) return { dir: '', name: norm };
	return { dir: norm.slice(0, idx), name: norm.slice(idx + 1) };
}

function setActiveDiffTab(mode) {
	const tc = $('diffTabCommit');
	const tu = $('diffTabCurrent');
	if (tc) tc.classList.toggle('active', mode === 'commit');
	if (tu) tu.classList.toggle('active', mode === 'current');
}

function setDiffLabels(mode) {
	const left = $('diffLabelLeft');
	const right = $('diffLabelRight');
	if (!left || !right) return;
	if (mode === 'current') {
		left.textContent = 'Neste commit (depois de restaurar)';
		right.textContent = 'Atual (como está agora)';
	} else {
		left.textContent = 'Novo (neste commit)';
		right.textContent = 'Antigo (antes do commit)';
	}
}

async function openDiffModal(project, c, isHead, dirty) {
	diffState = {
		project: project,
		commit: c,
		isHead: !!isHead,
		dirty: dirty || 0,
		mode: 'commit',
		files: [],
		activePath: '',
		token: ++diffToken,
		cache: {},
	};
	const title = $('diffTitle');
	const meta = $('diffMeta');
	if (title) title.textContent = c.isRestore ? '↩ Restore para ' + c.restoreOf : c.subject;
	if (meta) meta.textContent = c.short + ' · ' + fmtCommitDate(c.ts) + ' · ' + c.files + (c.files === 1 ? ' arquivo' : ' arquivos');
	setActiveDiffTab('commit');
	setDiffLabels('commit');
	const restoreBtn = $('diffRestore');
	if (restoreBtn) {
		restoreBtn.disabled = !!isHead;
		restoreBtn.title = isHead ? 'Este já é o commit atual' : '';
	}
	$('modalDiff').style.display = 'flex';
	loadDiffFiles();
}

function setDiffMode(mode) {
	if (!diffState) return;
	const normalized = (mode === 'current') ? 'current' : 'commit';
	if (diffState.mode === normalized) return;
	diffState.mode = normalized;
	diffState.cache = {};
	diffState.activePath = '';
	setActiveDiffTab(normalized);
	setDiffLabels(normalized);
	loadDiffFiles();
}

function clearDiffFilesAndViewer(msgFiles, msgViewer) {
	const files = $('diffFiles');
	const viewer = $('diffViewer');
	if (files) {
		files.innerHTML = '';
		if (msgFiles) {
			const d = document.createElement('div');
			d.className = 'diff-empty';
			d.textContent = msgFiles;
			files.appendChild(d);
		}
	}
	if (viewer) {
		viewer.innerHTML = '';
		if (msgViewer) {
			const d = document.createElement('div');
			d.className = 'diff-note';
			d.textContent = msgViewer;
			viewer.appendChild(d);
		}
	}
	const sum = $('diffSummary');
	if (sum) sum.textContent = '';
}

async function loadDiffFiles() {
	if (!diffState) return;
	const myToken = ++diffToken;
	diffState.token = myToken;
	const files = $('diffFiles');
	if (files) {
		files.innerHTML = '';
		const ld = document.createElement('div');
		ld.className = 'diff-empty';
		ld.textContent = 'Carregando…';
		files.appendChild(ld);
	}
	const viewer = $('diffViewer');
	if (viewer) viewer.innerHTML = '';

	const project = diffState.project;
	let r = null;
	try {
		r = await window.agentAPI.gitDiffFiles(project.projectRoot, project.slug, diffState.commit.hash, diffState.mode);
	} catch (e) {
		r = { ok: false, error: e.message };
	}
	if (!diffState || diffState.token !== myToken) return;

	if (!r || !r.ok) {
		const msg = (r && r.error) || 'Falha ao carregar diff.';
		clearDiffFilesAndViewer(msg, msg);
		return;
	}

	const list = Array.isArray(r.files) ? r.files : [];
	diffState.files = list;

	if (!list.length) {
		clearDiffFilesAndViewer('Nenhuma diferença nesta comparação.', 'Sem diferenças de texto.');
		return;
	}

	const listEl = $('diffFiles');
	if (listEl) listEl.innerHTML = '';

	let totalAdd = 0;
	let totalDel = 0;
	for (const f of list) {
		totalAdd += (f && typeof f.additions === 'number') ? f.additions : 0;
		totalDel += (f && typeof f.deletions === 'number') ? f.deletions : 0;
	}

	if (listEl) {
		for (const f of list) {
			const btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'diff-file';
			btn.dataset.path = f.path;
			btn.title = f.path;

			const top = document.createElement('div');
			top.className = 'diff-file-top';
			const badge = document.createElement('span');
			const st = (f.status === 'A' || f.status === 'M' || f.status === 'D') ? f.status : 'M';
			badge.className = 'diff-badge ' + st;
			badge.textContent = st;
			const parts = diffPathParts(f.path);
			const name = document.createElement('span');
			name.className = 'diff-file-name';
			name.textContent = parts.name;
			top.appendChild(badge);
			top.appendChild(name);

			const stat = document.createElement('div');
			stat.className = 'diff-file-stat';
			if (f.binary) {
				const b = document.createElement('span');
				b.textContent = 'bin';
				stat.appendChild(b);
			} else {
				const adds = (typeof f.additions === 'number') ? f.additions : 0;
				const dels = (typeof f.deletions === 'number') ? f.deletions : 0;
				if (adds > 0) {
					const a = document.createElement('span');
					a.className = 'diff-add';
					a.textContent = '+' + adds;
					stat.appendChild(a);
				}
				if (dels > 0) {
					const d = document.createElement('span');
					d.className = 'diff-del';
					d.textContent = '-' + dels;
					stat.appendChild(d);
				}
			}
			btn.appendChild(top);
			if (parts.dir) {
				const dir = document.createElement('div');
				dir.className = 'diff-file-dir';
				dir.textContent = parts.dir;
				btn.appendChild(dir);
			}
			btn.appendChild(stat);
			btn.addEventListener('click', () => { selectDiffFile(f.path); });
			listEl.appendChild(btn);
		}
	}

	const summary = $('diffSummary');
	if (summary) {
		let txt = list.length + (list.length === 1 ? ' arquivo' : ' arquivos') + ' · +' + totalAdd + ' −' + totalDel;
		if (r.truncated) {
			txt += ' · mostrando ' + list.length + ' de ' + (typeof r.total === 'number' ? r.total : list.length);
		}
		summary.textContent = txt;
	}

	selectDiffFile(list[0].path);
}

async function selectDiffFile(path) {
	if (!diffState) return;
	diffState.activePath = path;
	const listEl = $('diffFiles');
	if (listEl) {
		const nodes = listEl.querySelectorAll('.diff-file');
		for (const n of nodes) {
			if (n.dataset && n.dataset.path === path) n.classList.add('active');
			else n.classList.remove('active');
		}
	}
	const viewer = $('diffViewer');
	if (viewer) {
		viewer.innerHTML = '';
		const ld = document.createElement('div');
		ld.className = 'diff-note';
		ld.textContent = 'Carregando…';
		viewer.appendChild(ld);
	}

	const cacheKey = diffState.mode + ':' + path;
	if (diffState.cache[cacheKey]) {
		renderDiff(diffState.cache[cacheKey]);
		return;
	}

	const myToken = diffState.token;
	const project = diffState.project;
	let r = null;
	try {
		r = await window.agentAPI.gitDiffFile(project.projectRoot, project.slug, diffState.commit.hash, diffState.mode, path);
	} catch (e) {
		r = { ok: false, error: e.message };
	}
	if (!diffState || diffState.token !== myToken || diffState.activePath !== path) return;

	if (r && r.ok) diffState.cache[cacheKey] = r;
	renderDiff(r);
}

function makeLineEl(cls, text) {
	const el = document.createElement('div');
	el.className = cls;
	el.textContent = (text === undefined || text === null) ? '' : String(text);
	return el;
}

function renderDiff(res) {
	const viewer = $('diffViewer');
	if (!viewer) return;
	viewer.innerHTML = '';

	if (!res || !res.ok) {
		const msg = (res && res.error) || 'Falha ao carregar diff.';
		const n = document.createElement('div');
		n.className = 'diff-note';
		n.textContent = msg;
		viewer.appendChild(n);
		return;
	}
	if (res.binary) {
		const n = document.createElement('div');
		n.className = 'diff-note';
		n.textContent = 'Arquivo binário — sem pré-visualização.';
		viewer.appendChild(n);
		return;
	}
	const text = (typeof res.diff === 'string') ? res.diff : '';
	if (!text.trim()) {
		const n = document.createElement('div');
		n.className = 'diff-note';
		n.textContent = 'Sem diferenças de texto neste arquivo.';
		viewer.appendChild(n);
		return;
	}

	const rawLines = text.split('\n');
	const lines = [];
	for (let k = 0; k < rawLines.length; k++) {
		let ln = rawLines[k];
		if (ln.length > 0 && ln.charAt(ln.length - 1) === '\r') ln = ln.slice(0, -1);
		lines.push(ln);
	}
	if (lines.length > 0 && lines[lines.length - 1] === '') lines.pop();

	const grid = document.createElement('div');
	grid.className = 'diff-grid';

	let inHunk = false;
	let oldNo = 0;
	let newNo = 0;
	let pendingOld = [];
	let pendingNew = [];
	let emitted = 0;

	function appendEmptyLine() {
		grid.appendChild(makeLineEl('diff-ln empty', ''));
		grid.appendChild(makeLineEl('diff-code empty', ''));
		grid.appendChild(makeLineEl('diff-ln empty', ''));
		grid.appendChild(makeLineEl('diff-code empty', ''));
		emitted++;
	}

	function flush() {
		const maxLen = Math.max(pendingNew.length, pendingOld.length);
		for (let i = 0; i < maxLen; i++) {
			if (i < pendingNew.length) {
				grid.appendChild(makeLineEl('diff-ln add', String(newNo)));
				grid.appendChild(makeLineEl('diff-code add', pendingNew[i]));
				newNo++;
			} else {
				grid.appendChild(makeLineEl('diff-ln empty', ''));
				grid.appendChild(makeLineEl('diff-code empty', ''));
			}
			if (i < pendingOld.length) {
				grid.appendChild(makeLineEl('diff-ln del', String(oldNo)));
				grid.appendChild(makeLineEl('diff-code del', pendingOld[i]));
				oldNo++;
			} else {
				grid.appendChild(makeLineEl('diff-ln empty', ''));
				grid.appendChild(makeLineEl('diff-code empty', ''));
			}
			emitted++;
		}
		pendingNew = [];
		pendingOld = [];
	}

	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];

		if (!inHunk) {
			if (line.indexOf('@@') === 0) {
				inHunk = true;
				const m = line.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
				let sepText = line;
				if (m) {
					const oldStart = parseInt(m[1], 10);
					const oldCount = (m[2] !== undefined && m[2] !== '') ? parseInt(m[2], 10) : 1;
					const newStart = parseInt(m[3], 10);
					const newCount = (m[4] !== undefined && m[4] !== '') ? parseInt(m[4], 10) : 1;
					oldNo = Number.isFinite(oldStart) ? oldStart : 0;
					newNo = Number.isFinite(newStart) ? newStart : 0;
					const start = (newCount > 0) ? newNo : oldNo;
					const end = (newCount > 0) ? (newNo + newCount - 1) : (oldNo + oldCount - 1);
					sepText = 'Linhas ' + start + '–' + end;
				}
				const sep = document.createElement('div');
				sep.className = 'diff-sep';
				sep.textContent = sepText;
				grid.appendChild(sep);
			}
			continue;
		}

		if (line.indexOf('@@') === 0) {
			flush();
			const m = line.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
			let sepText = line;
			if (m) {
				const oldStart = parseInt(m[1], 10);
				const oldCount = (m[2] !== undefined && m[2] !== '') ? parseInt(m[2], 10) : 1;
				const newStart = parseInt(m[3], 10);
				const newCount = (m[4] !== undefined && m[4] !== '') ? parseInt(m[4], 10) : 1;
				oldNo = Number.isFinite(oldStart) ? oldStart : 0;
				newNo = Number.isFinite(newStart) ? newStart : 0;
				const start = (newCount > 0) ? newNo : oldNo;
				const end = (newCount > 0) ? (newNo + newCount - 1) : (oldNo + oldCount - 1);
				sepText = 'Linhas ' + start + '–' + end;
			}
			const sep = document.createElement('div');
			sep.className = 'diff-sep';
			sep.textContent = sepText;
			grid.appendChild(sep);
			continue;
		}

		if (line.indexOf('\\') === 0) continue;

		if (line.length === 0) {
			flush();
			grid.appendChild(makeLineEl('diff-ln', String(newNo)));
			grid.appendChild(makeLineEl('diff-code', ''));
			grid.appendChild(makeLineEl('diff-ln', String(oldNo)));
			grid.appendChild(makeLineEl('diff-code', ''));
			newNo++;
			oldNo++;
			emitted++;
			continue;
		}

		const ch = line.charAt(0);
		if (ch === ' ') {
			flush();
			const content = line.slice(1);
			grid.appendChild(makeLineEl('diff-ln', String(newNo)));
			grid.appendChild(makeLineEl('diff-code', content));
			grid.appendChild(makeLineEl('diff-ln', String(oldNo)));
			grid.appendChild(makeLineEl('diff-code', content));
			newNo++;
			oldNo++;
			emitted++;
			continue;
		}
		if (ch === '+') {
			pendingNew.push(line.slice(1));
			continue;
		}
		if (ch === '-') {
			pendingOld.push(line.slice(1));
			continue;
		}

		flush();
		appendEmptyLine();
	}

	flush();

	if (emitted === 0) {
		const n = document.createElement('div');
		n.className = 'diff-note';
		n.textContent = 'Sem diferenças de texto neste arquivo.';
		viewer.appendChild(n);
		return;
	}

	viewer.appendChild(grid);
	if (res.truncated) {
		const n = document.createElement('div');
		n.className = 'diff-note';
		n.textContent = 'Diff muito grande: mostrando só o início.';
		viewer.appendChild(n);
	}
}

function closeDiffModal() {
	const m = $('modalDiff');
	if (m) m.style.display = 'none';
	diffState = null;
	diffToken++;
}

function applyState(st) {
	if (!st) return;
	state.activeProjectId = st.activeProjectId || null;
	state.activeChatUuid = st.activeChatUuid || null;
	state.projects = st.projects || [];
	state.chats = st.chats || [];
	state.chat = st.chat || null;
	state.activeAssistantBlock = null;
	renderProjects();
	renderChats();
	renderHeader();
	updateComposerState(state.running);
	refreshGitBanner();
	refreshCommitsPanel();
}

function renderProjects() {
	const list = $('projectsList');
	list.innerHTML = '';
	if (!state.projects.length) {
		list.innerHTML = '<div class="session-empty">Nenhum projeto. Clique em + para criar.</div>';
		return;
	}
	for (const p of state.projects) {
		const btn = document.createElement('button');
		btn.className = 'project' + (p.id === state.activeProjectId ? ' active' : '');
		btn.type = 'button';
		btn.innerHTML =
			'<svg class="i"><use href="#i-folder"/></svg>' +
			'<span class="project-copy">' +
			'<span class="project-name">' + escapeHtml(p.name) + '</span>' +
			'<span class="project-path">' + escapeHtml(p.projectRoot || '(sem pasta)') + '</span>' +
			'</span>' +
			'<span class="project-menu">' +
			'<button type="button" title="Opções" data-menu="1"><svg class="i"><use href="#i-dots"/></svg></button>' +
			'</span>';
		btn.addEventListener('click', async (ev) => {
			const menuBtn = ev.target.closest('[data-menu]');
			if (menuBtn) { ev.stopPropagation(); openProjectMenu(p, menuBtn); return; }
			await activateProject(p.id);
		});
		list.appendChild(btn);
	}
}

function renderChats() {
	const list = $('sessionsList');
	const q = ($('sessionFilter').value || '').trim().toLowerCase();
	list.innerHTML = '';
	const filtered = state.chats.filter(c => {
		if (!q) return true;
		return (c.label || '').toLowerCase().includes(q) || (c.uuid || '').toLowerCase().includes(q);
	});
	if (!filtered.length) {
		list.innerHTML = '<div class="session-empty">' + (state.chats.length ? 'Nenhuma sessão corresponde à busca.' : 'Nenhuma sessão ainda.<br>Envie a primeira tarefa para criar.') + '</div>';
		return;
	}
	for (const c of filtered) {
		const isPending = (c.uuid || '').indexOf('pending-') === 0;
		const isActive = !!c.isActive;
		const item = document.createElement('button');
		item.className = 'session-item' + (isActive ? ' active' : '');
		item.type = 'button';
		item.title = isActive ? 'Sessão ativa' : 'Clique para carregar esta sessão';
		if (isActive) item.style.cursor = 'default';

		item.innerHTML =
			'<svg class="i"><use href="#i-chats"/></svg>' +
			'<span class="session-copy">' +
			'<span class="session-title">' +
			escapeHtml(c.label || c.uuid) +
			(isActive ? ' <span class="session-pending-badge" style="background:#1b2b45;color:#82acff;border-color:#30476c;">ativa</span>' : '') +
			(isPending && !isActive ? ' <span class="session-pending-badge">pendente</span>' : '') +
			'</span>' +
			'<span class="session-date">' + fmtDate(c.lastUsedAt) + ' · ' + fmtNum(c.sessionChars) + ' chars</span>' +
			'<span class="session-uuid">' + escapeHtml(c.uuid) + '</span>' +
			'</span>' +
			'<span class="session-actions">' +
			'<button type="button" title="Abrir em popup (somente leitura)" data-act="popup"><svg class="i"><use href="#i-external"/></svg></button>' +
			'<button type="button" title="Renomear" data-act="rename"><svg class="i"><use href="#i-edit"/></svg></button>' +
			'<button type="button" title="Excluir" data-act="delete"><svg class="i"><use href="#i-trash"/></svg></button>' +
			'</span>';

		item.addEventListener('click', async (ev) => {
			const act = ev.target.closest('[data-act]');
			if (act) {
				ev.stopPropagation();
				const action = act.getAttribute('data-act');
				if (action === 'popup') return openPopup(c);
				if (action === 'rename') return promptRenameChat(c);
				if (action === 'delete') return promptDeleteChat(c);
				return;
			}
			if (isActive) return;
			const wrap = $('sessionsWrap');
			if (wrap) wrap.open = false;
			await activateChat(c);
		});

		list.appendChild(item);
	}
}

function renderHeader() {
	const p = state.projects.find(x => x.id === state.activeProjectId);
	const c = state.chat;
	$('activeTitle').textContent = p ? p.name : '—';
	if (p && c) {
		$('activeSubtitle').textContent = (p.projectRoot || '(sem pasta)') + ' · ' + (c.label || c.uuid);
	} else if (p) {
		$('activeSubtitle').textContent = (p.projectRoot || '(sem pasta)') + ' · (envie a primeira tarefa para criar uma sessão)';
	} else {
		$('activeSubtitle').textContent = 'Crie um projeto para começar';
	}
}

let popupCloseHandler = null;

function openProjectMenu(project, anchorEl) {
	closeProjectMenu();
	const popup = $('projectPopup');
	popup.innerHTML = '';

	const itemRename = makePopupItem('i-edit', 'Renomear', false);
	itemRename.addEventListener('click', () => { closeProjectMenu(); promptRenameProject(project); });

	const itemRoot = makePopupItem('i-folder', 'Alterar pasta raiz', false);
	itemRoot.addEventListener('click', () => { closeProjectMenu(); promptEditRoot(project); });

	const sep = document.createElement('div');
	sep.className = 'project-popup-sep';

	const itemDelete = makePopupItem('i-trash', 'Remover projeto', true);
	itemDelete.addEventListener('click', () => { closeProjectMenu(); promptDeleteProject(project); });

	popup.appendChild(itemRename);
	popup.appendChild(itemRoot);
	popup.appendChild(sep);
	popup.appendChild(itemDelete);

	popup.style.display = 'flex';
	popup.style.visibility = 'hidden';

	const rect = anchorEl.getBoundingClientRect();
	const popupRect = popup.getBoundingClientRect();
	const viewportH = window.innerHeight;
	const viewportW = window.innerWidth;

	let left = rect.left;
	if (left + popupRect.width > viewportW - 8) left = Math.max(8, viewportW - popupRect.width - 8);
	let top = rect.bottom + 6;
	if (top + popupRect.height > viewportH - 8) top = Math.max(8, rect.top - popupRect.height - 6);

	popup.style.left = left + 'px';
	popup.style.top = top + 'px';
	popup.style.visibility = '';
	popup.classList.add('show');

	setTimeout(() => {
		popupCloseHandler = (ev) => { if (!popup.contains(ev.target)) closeProjectMenu(); };
		document.addEventListener('mousedown', popupCloseHandler);
	}, 0);

	document.addEventListener('keydown', onPopupKeydown);
}

function makePopupItem(iconId, label, danger) {
	const b = document.createElement('button');
	b.type = 'button';
	b.className = 'project-popup-item' + (danger ? ' danger' : '');
	b.innerHTML = '<svg class="i"><use href="#' + iconId + '"/></svg><span>' + escapeHtml(label) + '</span>';
	return b;
}

function closeProjectMenu() {
	const popup = $('projectPopup');
	if (!popup) return;
	popup.classList.remove('show');
	popup.style.display = 'none';
	if (popupCloseHandler) {
		document.removeEventListener('mousedown', popupCloseHandler);
		popupCloseHandler = null;
	}
	document.removeEventListener('keydown', onPopupKeydown);
}

function onPopupKeydown(ev) { if (ev.key === 'Escape') closeProjectMenu(); }
window.addEventListener('resize', () => closeProjectMenu());

async function activateProject(projectId) {
	if (state.running) return alert('Existe uma tarefa em andamento. Aguarde ou clique em Parar.');
	if (projectId === state.activeProjectId) return;
	showOverlay('Trocando de projeto…', 'Carregando o chat ativo do projeto.');
	try {
		const res = await window.projectsAPI.setActive(projectId);
		if (!res.ok) { overlayError(res.error, () => activateProject(projectId)); return; }
		hideOverlay();
		clearTimeline();
		applyState(res.state);
		try { await restoreHistory(); } catch (e) { }
		if (res.stats) applyStats(res.stats);
	} catch (e) { overlayError(e.message, () => activateProject(projectId)); }
}

async function activateChat(chat) {
	if (state.running) return alert('Existe uma tarefa em andamento. Aguarde ou clique em Parar.');
	if (!chat || !chat.uuid) return;
	if (chat.uuid === state.activeChatUuid) return;
	showOverlay('Trocando de sessão…', 'Carregando a sessão selecionada.');
	try {
		const res = await window.projectsAPI.switchChat(state.activeProjectId, chat.uuid);
		if (!res.ok) { overlayError(res.error, () => activateChat(chat)); return; }
		hideOverlay();
		clearTimeline();
		applyState(res.state);
		try { await restoreHistory(); } catch (e) { }
		if (res.stats) applyStats(res.stats);
	} catch (e) { overlayError(e.message, () => activateChat(chat)); }
}

function promptRenameProject(project) {
	$('modalRenameTitle').textContent = 'Renomear projeto';
	$('modalRenameCaption').textContent = 'Novo nome para "' + project.name + '".';
	$('renameInput').value = project.name;
	$('modalRename').style.display = 'flex';
	$('modalRename').dataset.mode = 'project';
	$('modalRename').dataset.id = project.id;
	$('renameRemoteWrap').style.display = 'none';
	setTimeout(() => $('renameInput').focus(), 50);
}

function promptRenameChat(chat) {
	$('modalRenameTitle').textContent = 'Renomear sessão';
	$('modalRenameCaption').textContent = 'Novo nome para "' + (chat.label || chat.uuid) + '".';
	$('renameInput').value = chat.label || '';
	$('modalRename').style.display = 'flex';
	$('modalRename').dataset.mode = 'chat';
	$('modalRename').dataset.id = chat.uuid;
	$('renameRemoteWrap').style.display = 'flex';
	$('renameRemote').checked = false;
	setTimeout(() => { $('renameInput').focus(); $('renameInput').select(); }, 50);
}

function promptDeleteProject(project) {
	pendingDelete = { type: 'project', id: project.id };
	let realCount = 0;
	try {
		if (project.id === state.activeProjectId) {
			realCount = state.chats.filter(c => (c.uuid || '').indexOf('pending-') !== 0).length;
		} else {
			realCount = project.chatCount || 0;
		}
	} catch (e) { realCount = project.chatCount || 0; }

	$('modalDeleteTitle').textContent = 'Remover projeto';
	$('modalDeleteCaption').textContent =
		'Remover "' + project.name + '"? ' +
		(realCount > 0 ? 'O projeto tem ' + realCount + ' sessão(ões) no DeepSeek.' : 'O projeto não tem sessões no DeepSeek (só placeholders).');

	$('modalDeleteBody').style.display = 'flex';
	$('modalDeleteRemote').checked = false;
	const labelSpan = $('modalDeleteBody').querySelector('span');
	if (labelSpan) {
		labelSpan.textContent = realCount > 0
			? 'Também apagar ' + realCount + ' sessão(ões) no DeepSeek (serão perdidas para sempre)'
			: 'Também apagar no DeepSeek (não há sessões reais para apagar)';
	}
	$('modalDelete').style.display = 'flex';
}

function promptDeleteChat(chat) {
	pendingDelete = { type: 'chat', id: chat.uuid };
	const isPending = (chat.uuid || '').indexOf('pending-') === 0;
	const isActive = !!chat.isActive;
	$('modalDeleteTitle').textContent = 'Remover sessão';
	$('modalDeleteCaption').textContent =
		'Remover "' + (chat.label || chat.uuid) + '" do projeto?' +
		(isActive ? ' Esta é a sessão ATIVA — depois de remover, o app vai criar uma nova sessão na próxima tarefa.' : '');
	$('modalDeleteBody').style.display = 'flex';
	$('modalDeleteRemote').checked = false;
	$('modalDeleteRemote').disabled = isPending;
	const labelSpan = $('modalDeleteBody').querySelector('span');
	if (labelSpan) {
		labelSpan.textContent = isPending
			? 'Esta sessão é um placeholder (ainda não foi registrada no DeepSeek)'
			: 'Também apagar no DeepSeek (a conversa será perdida para sempre)';
	}
	$('modalDelete').style.display = 'flex';
}

function promptEditRoot(project) {
	editingProjectId = project.id;
	modalProjectMode = 'editRoot';
	$('modalProjectTitle').textContent = 'Alterar pasta raiz';
	$('projectNameInput').value = project.name;
	$('projectNameInput').disabled = true;
	$('projectSlugInput').value = project.slug || slugify(project.name);
	$('projectSlugInput').disabled = true;
	$('projectRootInput').value = project.projectRoot || '';
	$('modalProject').style.display = 'flex';
}

function slugify(s) {
	return String(s || '')
		.normalize('NFD').replace(/[\u0300-\u036f]/g, '')  // remove acentos
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, '-')                        // nao-alfanumerico vira -
		.replace(/^-+|-+$/g, '')                            // tira - das pontas
		.slice(0, 60);
}


async function openNewProject() {
	modalProjectMode = 'create';
	editingProjectId = null;
	$('modalProjectTitle').textContent = 'Novo projeto';
	$('projectNameInput').disabled = false;
	$('projectNameInput').value = 'Projeto ' + String(state.projects.length + 1).padStart(2, '0');
	$('projectSlugInput').value = slugify($('projectNameInput').value);
	$('projectSlugInput').disabled = false;
	$('projectRootInput').value = '';
	$('modalProject').style.display = 'flex';
	setTimeout(() => { $('projectNameInput').focus(); $('projectNameInput').select(); }, 50);
}


// Auto-preenche o slug enquanto o usuario digita o nome.
// Se o usuario editar o slug manualmente, para de auto-preencher.
(function () {
	let slugManual = false;
	const nameEl = document.getElementById('projectNameInput');
	const slugEl = document.getElementById('projectSlugInput');
	if (!nameEl || !slugEl) return;

	slugEl.addEventListener('input', () => {
		slugManual = slugEl.value.trim().length > 0;
	});
	nameEl.addEventListener('input', () => {
		if (slugManual) return;
		slugEl.value = slugify(nameEl.value);
	});

	// Ao abrir "Novo projeto", reset do flag
	const origOpen = window.openNewProject;
	// (o openNewProject ja seta o slug — mas o flag precisa resetar)
	const btn = document.getElementById('btnAddProject');
	if (btn) btn.addEventListener('click', () => { slugManual = false; });
})();



async function openPopup(chat) {
	if (!chat || !chat.uuid) return;
	try {
		const res = await window.projectsAPI.openSessionPopup(chat.uuid, chat.label);
		if (!res.ok) showDiag('Falha ao abrir popup: ' + res.error, false);
	} catch (e) { showDiag('Erro: ' + e.message, false); }
}

function ensureEmptyRemoved() {
	const em = $('emptyState');
	if (em) em.remove();
}

function clearTimeline() {
	const c = $('chatContent');
	c.innerHTML = '<div class="empty" id="emptyState">Sem mensagens ainda.<br>Envie uma tarefa abaixo para começar — a sessão é criada automaticamente.</div>';
	pendingCommands.clear();
	state.activeAssistantBlock = null;
	const comp = document.querySelector('.compacting');
	if (comp) comp.remove();
}

function scrollToBottom() {
	const t = $('timeline');
	if (t) t.scrollTop = t.scrollHeight;
}

function appendNode(node) {
	ensureEmptyRemoved();
	$('chatContent').appendChild(node);
	scrollToBottom();
}

function appendUserMessage(text) {
	const row = document.createElement('div');
	row.className = 'msg-row user';
	row.innerHTML = '<div class="user-bubble">' + escapeHtml(text) + '</div>';
	appendNode(row);
}



function appendAssistantMessage(text, time, opts) {
	opts = opts || {};
	const row = document.createElement('div');
	row.className = 'msg-row';
	const avatarHtml = '<div class="avatar"><svg class="i"><use href="#i-spark"/></svg></div>';
	const whoHtml = '<div class="who">DeepSeek Agent <span class="time">' + escapeHtml(time || timeNow()) + '</span></div>';
	const textHtml = '<div class="assistant-text">' + escapeHtml(text) + '</div>';

	let extraHtml = '';
	if (opts.needsReview) {
		const files = Array.isArray(opts.touchedFiles) ? opts.touchedFiles : [];
		const filesHtml = files.length > 0
			? '<div class="review-files">Arquivos: ' + files.map(function (f) { return escapeHtml(f); }).join(', ') + '</div>'
			: '';
		extraHtml =
			'<div class="review-btn-wrap">' +
			'<button class="review-btn" type="button" data-review="1">🤖 Pedir revisão ao agente</button>' +
			filesHtml +
			'</div>';
	}

	row.innerHTML = avatarHtml +
		'<div class="assistant-body">' +
		whoHtml + textHtml + extraHtml +
		'</div>';

	appendNode(row);

	if (opts.needsReview) {
		const btn = row.querySelector('[data-review]');
		if (btn) {
			btn.addEventListener('click', async () => {
				btn.disabled = true;
				btn.textContent = '🤖 Revisando…';
				await requestReview(opts);
			});
		}
	}
	return row;
}




// ============================================================
// Render de segmento do assistente (HTML ja preparado no loop)
// ============================================================
function appendAssistantSegment(html) {
	removeLiveStatus();
	const clean = sanitizeHtml(html || '');
	if (!clean) return null;

	const block = document.createElement('div');
	block.className = 'msg-row';
	block.innerHTML =
		'<div class="avatar"><svg class="i"><use href="#i-spark"/></svg></div>' +
		'<div class="assistant-body">' +
		'<div class="who">DeepSeek Agent <span class="time">' + escapeHtml(timeNow()) + '</span></div>' +
		'<div class="assistant-text markdown-body"></div>' +
		'</div>';
	appendNode(block);

	const textEl = block.querySelector('.assistant-text');
	if (textEl) textEl.innerHTML = clean;

	state.activeAssistantBlock = block;
	scrollToBottom();
	return block;
}

function resetActiveAssistantBlock() {
	state.activeAssistantBlock = null;
}

// ============================================================
// Sanitizacao de HTML (allowlist)
// ============================================================
const ALLOWED_TAGS = new Set([
	'p', 'div', 'span', 'br', 'hr',
	'ul', 'ol', 'li',
	'pre', 'code',
	'strong', 'b', 'em', 'i', 'u', 's', 'del',
	'a', 'blockquote',
	'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
	'table', 'thead', 'tbody', 'tr', 'th', 'td',
	'input',
	'img',
]);

const ALLOWED_CLASSES = new Set([
	'code-block',
	// marked-alert (caso o marked rode e gere os alertas)
	'markdown-alert',
	'markdown-alert-note',
	'markdown-alert-tip',
	'markdown-alert-important',
	'markdown-alert-warning',
	'markdown-alert-caution',
	'markdown-alert-title',
]);

function isAllowedClass(cls) {
	if (ALLOWED_CLASSES.has(cls)) return true;
	if (cls.indexOf('language-') === 0) return true;
	return false;
}

function enhanceCodeBlocks(root, doc) {
	const pres = Array.from(root.querySelectorAll('pre'));
	for (const pre of pres) {
		if (pre.parentElement && pre.parentElement.classList.contains('code-block')) continue;
		let lang = '';
		const prev = pre.previousElementSibling;
		if (prev) {
			const m = (prev.textContent || '').trim().match(/^([A-Za-z0-9_+#.-]*)\s*(?:Copy|Copiar)\s*(?:Download|Baixar)?$/i);
			if (m) { lang = m[1]; prev.remove(); }
		}
		if (!lang) {
			const code = pre.querySelector('code');
			const cm = code ? (code.className || '').match(/(?:^|\s)language-([A-Za-z0-9_+#.-]+)/) : null;
			if (cm) lang = cm[1];
		}
		const wrap = doc.createElement('div');
		wrap.className = 'code-block';
		const head = doc.createElement('div');
		head.className = 'code-head';
		const label = doc.createElement('span');
		label.className = 'code-lang';
		label.textContent = lang || 'c\u00f3digo';
		const btn = doc.createElement('button');
		btn.type = 'button';
		btn.className = 'code-copy';
		btn.textContent = 'Copiar';
		head.appendChild(label);
		head.appendChild(btn);
		pre.parentNode.insertBefore(wrap, pre);
		wrap.appendChild(head);
		wrap.appendChild(pre);
		if (lang && window.highlightAPI) {
			let target = pre.querySelector('code');
			if (!target) {
				target = doc.createElement('code');
				target.textContent = pre.textContent;
				pre.textContent = '';
				pre.appendChild(target);
			}
			const out = window.highlightAPI.highlight(target.textContent, lang);
			if (typeof out === 'string' && out.length > 0) {
				target.innerHTML = out;
				target.classList.add('hljs');
			}
		}
	}
}

function sanitizeHtml(html) {
	let raw = String(html || '');
	raw = raw.replace(/<br\s*\/?>/gi, '\n');
	raw = raw.replace(/~~([\s\S]*?)~~/g, '<del>$1</del>');

	// Remove TODOS os <span>...</span> do DeepSeek antes de parsear.
	// O DeepSeek quebra comandos em vários spans, então o regex de
	// comando não casa no text node individual. Sem span, o texto
	// fica contínuo e o regex pega.
	// (Repetimos até não sobrar span aninhado.)
	for (let i = 0; i < 5; i++) {
		const antes = raw;
		raw = raw.replace(/<span\b[^>]*>/gi, '').replace(/<\/span>/gi, '');
		if (raw === antes) break;
	}

	const looksLikeHtml = /^\s*<(?:div|p|h[1-6]|ul|ol|table|pre|blockquote|section|article|header|footer)\b/i.test(raw);
	if (!looksLikeHtml && window.markdownAPI) {
		try {
			const md = window.markdownAPI.parse(raw);
			if (typeof md === 'string' && md.length > 0) raw = md;
		} catch (e) { }
	}

	const doc = new DOMParser().parseFromString('<div>' + raw + '</div>', 'text/html');
	const root = doc.body.firstChild;

	// Remove comandos <<<...>>> de qualquer texto (agora contínuo).
	const ALL_CMD_RE = /<<<[\s\S]*?>>>/g;

	// 1) Remove elementos cujo texto (sem comando e sem espaços) é vazio.
	const elems = root.querySelectorAll('p, div, li, h1, h2, h3, h4, h5, h6, pre, code');
	for (const el of Array.from(elems)) {
		const t = (el.textContent || '').trim();
		if (!t) continue;
		if (t.indexOf('<<<') === -1) continue;
		const semComando = t.replace(ALL_CMD_RE, '').replace(/\s+/g, '');
		if (semComando.length === 0) {
			el.remove();
		}
	}

	// 2) Nos text nodes restantes, remove comandos inline.
	const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
	const textNodes = [];
	while (walker.nextNode()) textNodes.push(walker.currentNode);
	for (const tn of textNodes) {
		const before = tn.nodeValue;
		if (!before || before.indexOf('<<<') === -1) continue;
		const after = before.replace(ALL_CMD_RE, '').replace(/[ \t]+\n/g, '\n');
		if (after !== before) tn.nodeValue = after;
	}

	// 3) Processa alertas via DOM.
	const bqs = root.querySelectorAll('blockquote');
	for (const bq of bqs) {
		const text = (bq.textContent || '').trim();
		const m = text.match(/^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]/i);
		if (!m) continue;
		const type = m[1].toUpperCase();
		const cls = 'markdown-alert markdown-alert-' + type.toLowerCase();
		const title = type.charAt(0) + type.slice(1).toLowerCase();
		const rest = text.slice(m[0].length).trim();
		const div = doc.createElement('div');
		div.className = cls;
		const pt = doc.createElement('p');
		pt.className = 'markdown-alert-title';
		pt.textContent = title;
		const pb = doc.createElement('p');
		pb.textContent = rest;
		div.appendChild(pt);
		div.appendChild(pb);
		bq.replaceWith(div);
	}

	function walk(node) {
		if (!node) return;
		if (node.nodeType === 3) return;
		if (node.nodeType !== 1) { node.remove(); return; }

		const tag = node.tagName.toLowerCase();
		if (!ALLOWED_TAGS.has(tag)) { node.remove(); return; }

		for (const attr of Array.from(node.attributes)) {
			const name = attr.name.toLowerCase();
			if (name.startsWith('on')) { node.removeAttribute(attr.name); continue; }
			if (name === 'href') {
				// ITEM 9: href so pode ser http:, https: ou mailto:.
				// Le o valor DECODIFICADO via getAttribute (nao o texto cru),
				// remove chars de controle/espace e testa. Se nao casar, remove.
				const decoded = node.getAttribute('href') || '';
				const clean = decoded.replace(/[\u0000-\u0020\u007f-\u009f]/g, '');
				if (!/^(https?:|mailto:)/i.test(clean)) {
					node.removeAttribute('href');
				}
				continue;
			}
			if (name === 'target' || name === 'rel') continue;
			if (name === 'class') {
				const classes = attr.value.split(/\s+/).filter(function (c) { return isAllowedClass(c); });
				if (classes.length === 0) node.removeAttribute('class');
				else node.className = classes.join(' ');
				continue;
			}
			if (tag === 'input') {
				if (name === 'type' || name === 'checked' || name === 'disabled') continue;
				node.removeAttribute(attr.name);
				continue;
			}
			node.removeAttribute(attr.name);
		}

		if (tag === 'a' && node.getAttribute('target') === '_blank') {
			node.setAttribute('rel', 'noopener noreferrer');
		}

		for (const child of Array.from(node.childNodes)) walk(child);
	}

	for (const child of Array.from(root.childNodes)) walk(child);
	enhanceCodeBlocks(root, doc);
	return root.innerHTML;
}

function appendSessionMarker(text) {
	const d = document.createElement('div');
	d.className = 'session-marker';
	d.setAttribute('role', 'separator');
	d.innerHTML = '<span>' + escapeHtml(text) + '</span>';
	appendNode(d);
}

function appendCompacting() {
	const d = document.createElement('div');
	d.className = 'compacting';
	d.setAttribute('role', 'status');
	d.innerHTML =
		'<span class="pulse"></span>' +
		'<div>' +
		'<div class="compacting-title">Compactando sessão...</div>' +
		'<div class="compacting-desc">O contexto está sendo resumido em uma nova sessão.</div>' +
		'</div>';
	appendNode(d);
	return d;
}

function removeCompacting() {
	const c = document.querySelector('.compacting');
	if (c) c.remove();
}

function eventIconForType(type) {
	if (type === 'read') return 'i-file';
	if (type === 'run') return 'i-terminal';
	if (type === 'edit' || type === 'write') return 'i-diff';
	if (type === 'grep' || type === 'glob' || type === 'ls') return 'i-search';
	return 'i-file';
}

function eventTitleForCmd(cmd) {
	const type = cmd.type || '';
	const arg = cmd.arg || '';
	if (type === 'read') return 'Leitura de arquivo: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	if (type === 'run') return 'Log de processo: <span class="mono-path">' + escapeHtml(arg || '(comando)') + '</span>';
	if (type === 'edit') return 'Alteração de código: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	if (type === 'write') return 'Novo arquivo: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	if (type === 'grep') return 'Busca: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	if (type === 'glob') return 'Listagem: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	if (type === 'ls') return 'Diretório: <span class="mono-path">' + escapeHtml(arg) + '</span>';
	return (type || 'cmd').toUpperCase() + (arg ? ': ' + escapeHtml(arg) : '');
}

function makeEventCard(cmdId, type) {
	const card = document.createElement('div');
	card.className = 'activity';
	const details = document.createElement('details');
	details.className = 'event-card is-pending';
	details.dataset.cmdId = cmdId;
	details.dataset.type = type;
	const summary = document.createElement('summary');
	summary.className = 'event-summary';
	summary.innerHTML =
		'<span class="event-icon"><svg class="i"><use href="#' + eventIconForType(type) + '"/></svg></span>' +
		'<span class="event-copy">' +
		'<span class="event-title"></span>' +
		'<span class="event-desc">aguardando resultado...</span>' +
		'</span>' +
		'<span class="event-trailing"><svg class="i"><use href="#i-chevron"/></svg></span>';
	const detail = document.createElement('div');
	detail.className = 'event-detail';
	details.appendChild(summary);
	details.appendChild(detail);
	card.appendChild(details);
	return card;
}

function addCommandCard(cmd) {
	const id = cmd.id || ('c-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8));
	const card = makeEventCard(id, cmd.type);
	const title = card.querySelector('.event-title');
	title.innerHTML = eventTitleForCmd(cmd);
	appendNode(card);
	pendingCommands.set(id, { card });
	return card;
}

function renderDiffLines(diff) {
	let html = '';
	if (diff.removed && diff.removed.length) {
		for (const l of diff.removed) html += '<span class="diff-remove">- ' + escapeHtml(l) + '</span>';
	}
	if (diff.added && diff.added.length) {
		for (const l of diff.added) html += '<span class="diff-add">+ ' + escapeHtml(l) + '</span>';
	}
	if (!html) html = '<em style="color:#7f93ac">(sem alterações)</em>';
	return html;
}

function renderRunStreams(result) {
	let html = '<div class="streams">';
	if (result.stdout) html += '<div class="stream-block"><span class="stream-label">stdout</span><pre>' + escapeHtml(result.stdout) + '</pre></div>';
	if (result.stderr) html += '<div class="stream-block stderr"><span class="stream-label">stderr</span><pre>' + escapeHtml(result.stderr) + '</pre></div>';
	if (!result.stdout && !result.stderr) html += '<div class="stream-block"><pre>(sem saída)</pre></div>';
	const exitCode = typeof result.exitCode === 'number' ? result.exitCode : -1;
	const killed = !!result.killed;
	const exitLabel = killed
		? '⏱ Encerrado' + (result.signal ? ' — ' + result.signal : '')
		: (exitCode === 0 ? '✓ exit 0' : '✗ exit ' + exitCode);
	const cls = (exitCode === 0 && !killed) ? 'ok' : 'err';
	html += '<div class="exit-tag ' + cls + '">' + escapeHtml(exitLabel) + '</div>';
	html += '</div>';
	return html;
}

function attachResultToCard(card, result) {
	card.classList.remove('is-pending');
	card.classList.add(result.ok ? 'is-ok' : 'is-err');
	const desc = card.querySelector('.event-desc');
	const detail = card.querySelector('.event-detail');
	const trailing = card.querySelector('.event-trailing');
	const type = result.type || card.dataset.type;

	if (type === 'run' && typeof result.stdout === 'string') {
		if (desc) desc.textContent = result.ok ? 'Comando finalizado' : 'Comando falhou';
		if (detail) detail.innerHTML = renderRunStreams(result);
		if (trailing) {
			const exitCode = typeof result.exitCode === 'number' ? result.exitCode : -1;
			const killed = !!result.killed;
			const cls = (exitCode === 0 && !killed) ? 'good' : 'warn';
			const label = killed ? 'killed' : ('exit ' + exitCode);
			trailing.innerHTML = '<span class="tag ' + cls + '">' + escapeHtml(label) + '</span><svg class="i"><use href="#i-chevron"/></svg>';
		}
		return;
	}

	if (type === 'edit' || type === 'write') {
		if (result.diff) {
			if (desc) desc.textContent = (result.diff.added && result.diff.added.length) + ' linha(s) adicionada(s) · ' + (result.diff.removed && result.diff.removed.length) + ' removida(s)';
			if (detail) detail.innerHTML = renderDiffLines(result.diff);
			if (trailing) trailing.innerHTML = '<span class="tag warn">diff</span><svg class="i"><use href="#i-chevron"/></svg>';
			return;
		}
	}

	if (desc) desc.textContent = result.ok ? 'Concluído' : 'Erro';
	let content = stripProtocol(result.result || '');
	if (!content) content = '(sem conteúdo)';
	if (detail) detail.textContent = content;
	if (trailing && !result.ok) {
		trailing.innerHTML = '<span class="tag warn">erro</span><svg class="i"><use href="#i-chevron"/></svg>';
	}
}

function addResultCard(result) {
	if (result && result.type === 'message') {
		appendAssistantSegment(result.html || '');
		return;
	}
	const id = result.id;
	if (id && pendingCommands.has(id)) {
		const entry = pendingCommands.get(id);
		pendingCommands.delete(id);
		clearTimeout(entry.timer);
		attachResultToCard(entry.card.querySelector('.event-card') || entry.card, result);
		return;
	}
	const cmd = { id: id || ('c-' + Date.now()), type: result.type || 'system', arg: result.arg || '' };
	const card = addCommandCard(cmd);
	const ecard = card.querySelector('.event-card') || card;
	const cid = ecard.dataset.cmdId;
	if (cid && pendingCommands.has(cid)) {
		const entry = pendingCommands.get(cid);
		pendingCommands.delete(cid);
		clearTimeout(entry.timer);
	}
	attachResultToCard(ecard, result);
}

function applyStats(s) {
	if (!s) return;
	state.stats = s;
	state.running = !!s.running;
	$('statTasks').textContent = s.tasks;
	$('statMsgs').textContent = s.messages;
	$('statChars').textContent = fmtNum(s.chars);
	$('statTokens').textContent = fmtNum(s.approxTokens);

	const cWrap = $('statCharsWrap');
	const tWrap = $('statTokensWrap');
	cWrap.classList.remove('warn', 'danger');
	tWrap.classList.remove('warn', 'danger');
	if (s.approxTokens > TOKENS_DANGER) { cWrap.classList.add('danger'); tWrap.classList.add('danger'); }
	else if (s.approxTokens > TOKENS_WARN) { cWrap.classList.add('warn'); tWrap.classList.add('warn'); }

	updateCompactBanner(s);
	applyRunningState(s.running);

	if (typeof s.chatWindowVisible === 'boolean' && s.chatWindowVisible !== state.chatWindowVisible) {
		applyChatWindowState(s.chatWindowVisible);
	}
}

function updateCompactBanner(s) {
	const b = $('compactBanner');
	const msg = $('compactBannerMsg');
	const btn = $('compactBannerBtn');
	if (!s) { b.style.display = 'none'; return; }
	const danger = (s.approxTokens > TOKENS_DANGER) || (s.tasks >= TASKS_DANGER);
	const warn = (s.approxTokens > TOKENS_WARN) || (s.tasks >= TASKS_WARN);
	if (!warn && !danger) { b.style.display = 'none'; b.classList.remove('danger'); return; }
	b.style.display = 'flex';
	b.classList.toggle('danger', danger);

	if (s.running) {
		msg.textContent = '⏳ Compacte quando a tarefa terminar — ' + fmtNum(s.approxTokens) + ' tokens, ' + s.tasks + ' tarefa' + (s.tasks === 1 ? '' : 's');
		btn.disabled = true; btn.style.opacity = '0.5'; btn.style.cursor = 'not-allowed'; btn.textContent = '⏳ Aguarde a tarefa';
	} else if (danger) {
		msg.textContent = '🔴 Compacte agora — ' + fmtNum(s.approxTokens) + ' tokens, ' + s.tasks + ' tarefa' + (s.tasks === 1 ? '' : 's');
		btn.disabled = false; btn.style.opacity = ''; btn.style.cursor = ''; btn.textContent = '📦 Compactar agora';
	} else {
		msg.textContent = '⚠️ Hora de compactar — ' + fmtNum(s.approxTokens) + ' tokens, ' + s.tasks + ' tarefa' + (s.tasks === 1 ? '' : 's');
		btn.disabled = false; btn.style.opacity = ''; btn.style.cursor = ''; btn.textContent = '📦 Compactar agora';
	}
}

function updateCompactButton(running) {
	const compactBtn = $('btnCompactNow');
	if (!compactBtn) return;
	const hasMessages = !!(state.stats && state.stats.messages > 0);
	compactBtn.disabled = !!running || !hasMessages;
}

function updateComposerState(running) {
	const noProject = !state.activeProjectId;
	$('messageInput').disabled = noProject;
	$('btnSend').disabled = !!running || noProject;
}

function applyRunningState(running) {
	const comp = $('composer');
	comp.classList.toggle('working', !!running);
	const workDots = $('workDots');
	if (workDots) workDots.style.display = running ? 'flex' : 'none';
	updateComposerState(running);
	updateCompactButton(running);
	const btn = $('compactBannerBtn');
	const msg = $('compactBannerMsg');
	const b = $('compactBanner');
	if (btn && b && b.style.display === 'flex') {
		if (running) {
			btn.disabled = true; btn.style.opacity = '0.5'; btn.style.cursor = 'not-allowed'; btn.textContent = '⏳ Aguarde a tarefa';
			if (msg && state.stats) {
				msg.textContent = '⏳ Compacte quando a tarefa terminar — ' + fmtNum(state.stats.approxTokens) + ' tokens, ' + state.stats.tasks + ' tarefa' + (state.stats.tasks === 1 ? '' : 's');
			}
		} else if (state.stats) {
			updateCompactBanner(state.stats);
		}
	}
}

function appendLiveStatus(text) {
	const row = document.createElement('div');
	row.className = 'msg-row live-status';
	row.innerHTML =
		'<div class="avatar"><svg class="i"><use href="#i-spark"/></svg></div>' +
		'<div class="assistant-body">' +
		'<div class="who">DeepSeek Agent <span class="time">' + escapeHtml(timeNow()) + '</span></div>' +
		'<div class="live-status-text">' + escapeHtml(text) + '<span class="dots">…</span></div>' +
		'</div>';
	appendNode(row);
	return row;
}

function updateLiveStatus(text) {
	const el = document.querySelector('.live-status .live-status-text');
	if (!el) return;
	el.innerHTML = escapeHtml(text) + '<span class="dots">…</span>';
}

function removeLiveStatus() {
	removeStreamBox();
	const el = document.querySelector('.live-status');
	if (el) el.remove();
}

function removeStreamBox() {
	const el = document.querySelector('#chatContent .stream-box');
	if (el) el.remove();
}

function updateStreamBox(text) {
	let box = document.querySelector('#chatContent .stream-box');
	if (typeof text !== 'string' || !text.trim()) { if (box) box.remove(); return; }
	const clean = text.replace(/<<<[\s\S]*?>>>/g, '').replace(/<<<[\s\S]*$/, '').replace(/<{1,2}$/, '').trim();
	if (!clean) { if (box) box.remove(); return; }
	let html = null;
	if (window.markdownAPI) { try { html = window.markdownAPI.parse(clean); } catch (e) { } }
	if (typeof html !== 'string') html = '<p>' + escapeHtml(clean) + '</p>';
	const doc = new DOMParser().parseFromString('<div>' + html + '</div>', 'text/html');
	const root = doc.body.firstChild;
	root.querySelectorAll('script, iframe, object, embed, style, link').forEach(function (n) { n.remove(); });
	root.querySelectorAll('*').forEach(function (n) {
		Array.from(n.attributes).forEach(function (a) { if (/^on/i.test(a.name)) n.removeAttribute(a.name); });
	});
	const t = $('timeline');
	const nearBottom = !t || (t.scrollHeight - t.scrollTop - t.clientHeight) < 80;
	if (!box) {
		box = document.createElement('div');
		box.className = 'msg-row stream-box';
		box.innerHTML = '<div class="stream-text"></div>';
		appendNode(box);
	}
	box.querySelector('.stream-text').innerHTML = root.innerHTML;
	if (nearBottom) scrollToBottom();
}

function applyChatWindowState(visible) {
	state.chatWindowVisible = !!visible;
	const dot = $('statusDot');
	const txt = $('engineStatus');
	if (visible) { dot.classList.remove('off'); txt.textContent = 'DeepSeek conectado'; }
	else { dot.classList.add('off'); txt.textContent = 'DeepSeek oculto'; }
}

async function executeRun(task, opts) {
	opts = opts || {};
	const displayUserText = opts.displayUserText || task;
	const project = state.projects.find(p => p.id === state.activeProjectId);
	const projectRoot = project ? project.projectRoot : '';

	$('messageInput').value = '';
	clearPendingTimers();
	resetActiveAssistantBlock();
	appendUserMessage(displayUserText);
	appendLiveStatus('Iniciando agente');

	state.running = true;
	applyRunningState(true);

	try {
		const res = await window.agentAPI.run(task, projectRoot);
		if (!res.ok) {
			removeLiveStatus();
			appendAssistantMessage('❌ ERRO: ' + res.error, timeNow());
		} else if (res.result && res.result.aborted) {
			removeLiveStatus();
			appendAssistantMessage('⚠️ ABORTADO em ' + res.result.turns + ' turnos.\n\n' + (res.result.summary || ''), timeNow());
		} else {
			const summary = res.result.summary || '';

			// Conta quantos blocos de assistente o loop.js JA renderizou no DOM.
			// Se for 0, renderiza o summary (fallback). Se for >=1, nao duplica.
			const blocksRendered = document.querySelectorAll('#chatContent .assistant-text').length;

			if (blocksRendered === 0 && summary) {
				const row = appendAssistantMessage('', timeNow(), {
					needsReview: !!res.result.needsReview,
					touchedFiles: res.result.touchedFiles || [],
					reviewPrompt: res.result.reviewPrompt || '',
					originalTask: opts.originalTask || task,
				});
				const textEl = row ? row.querySelector('.assistant-text') : null;
				if (textEl) {
					textEl.classList.add('markdown-body');
					textEl.innerHTML = sanitizeHtml(summary);
					scrollToBottom();
				}
			} else if (blocksRendered > 0 && res.result.needsReview) {
				// Se precisa revisao, adiciona o botao no ULTIMO bloco renderizado
				const blocks = document.querySelectorAll('#chatContent .assistant-text');
				const lastBlock = blocks[blocks.length - 1];
				const body = lastBlock ? lastBlock.closest('.assistant-body') : null;
				if (body && !body.querySelector('.review-btn')) {
					const files = (res.result.touchedFiles || []);
					const filesHtml = files.length > 0
						? '<div class="review-files">Arquivos: ' + files.map(function (f) { return escapeHtml(f); }).join(', ') + '</div>'
						: '';
					const wrap = document.createElement('div');
					wrap.className = 'review-btn-wrap';
					wrap.innerHTML = '<button class="review-btn" type="button">🤖 Pedir revisão ao agente</button>' + filesHtml;
					body.appendChild(wrap);
					const btn = wrap.querySelector('.review-btn');
					if (btn) {
						btn.addEventListener('click', async () => {
							btn.disabled = true;
							btn.textContent = '🤖 Revisando…';
							await requestReview({
								needsReview: true,
								touchedFiles: files,
								reviewPrompt: res.result.reviewPrompt || '',
								originalTask: opts.originalTask || task,
							});
						});
					}
				}
			}
		}
		if (res.ok && res.result && Array.isArray(res.result.touchedFiles) && res.result.touchedFiles.length > 0) {
			const commit = res.result.commit;
			if (commit && commit.ok && !commit.skipped) {
				showDiag('✅ Commit feito (' + (commit.hash || '') + '): ' + (commit.message || ''), true);
			} else if (commit && !commit.ok) {
				showDiag('Falha no commit automatico: ' + (commit.error || 'erro desconhecido'), false);
			}
			try { await refreshCommitsPanel(); } catch (e) { }
		}
		if (res.stats) applyStats(res.stats);
		if (res.state) applyState(res.state);
	} catch (e) {
		removeLiveStatus();
		appendAssistantMessage('❌ ERRO: ' + e.message, timeNow());
	} finally {
		removeLiveStatus();
		state.running = false;
		applyRunningState(false);
		clearPendingTimers();
		try { await persistTimeline(); } catch (e) { }
	}
}
async function runTask() {
	const t = $('messageInput').value.trim();
	if (!t) return;
	if (state.running) return;
	if (!state.activeProjectId) return alert('Crie um projeto primeiro.');
	const project = state.projects.find(p => p.id === state.activeProjectId);
	const projectRoot = project ? project.projectRoot : '';
	if (!projectRoot) return alert('Defina a pasta raiz do projeto (menu do projeto → Alterar pasta raiz).');
	await executeRun(t, { displayUserText: t });
}

async function requestReview(data) {
	if (!data || !data.reviewPrompt) {
		showDiag('Não foi possível montar o prompt de revisão.', false);
		return;
	}
	if (state.running) return;
	await executeRun(data.reviewPrompt, {
		displayUserText: '🤖 Pedir revisão ao agente (arquivos: ' +
			(data.touchedFiles && data.touchedFiles.length ? data.touchedFiles.join(', ') : '—') + ')',
		originalTask: data.originalTask || '',
	});
}

async function stopTask() {
	if (!state.running) return;
	try { await window.agentAPI.abort(); } catch (e) { showDiag('Erro ao parar: ' + e.message, false); }
}

async function doCompact() {
	if (state.running) return;
	if (!confirm('Compactar a sessão atual?\n\nO app vai:\n• pedir um resumo ao modelo\n• criar uma nova sessão no DeepSeek\n• reinjetar o resumo na nova sessão\n\nA sessão anterior fica no histórico (Sessions) para consulta.')) return;
	appendCompacting();
	try {
		const res = await window.agentAPI.compact();
		removeCompacting();
		if (!res.ok) {
			appendAssistantMessage('❌ Compactação falhou: ' + res.error, timeNow());
		} else {
			clearTimeline();
			appendSessionMarker('Nova sessão (compactada) · ' + timeNow());
			showDiag('Nova sessão criada com o resumo da anterior.', true);
		}
		if (res.stats) applyStats(res.stats);
		try { const st = await window.projectsAPI.state(); applyState(st); await persistTimeline(); } catch (e) { }
	} catch (e) {
		removeCompacting();
		appendAssistantMessage('❌ ERRO: ' + e.message, timeNow());
	}
}

function updateRunBatchCount() {
	const count = document.querySelectorAll('#runModalList input[data-role="main"]:checked').length;
	$('runModalCount').textContent = count;
	$('runModalRun').disabled = count === 0;
}

function showRunBatchModal(items) {
	pendingRunBatch = { items };
	const list = $('runModalList');
	list.innerHTML = '';
	items.forEach((item, i) => {
		const row = document.createElement('div');
		row.className = 'cmd-item';
		row.dataset.idx = i;

		// ITEM 11: WRITE/EDIT sensivel entra no mesmo modal do RUN, mas com
		// rotulo diferente e SEM checkbox "Sempre permitir". O path vai via
		// textContent (nunca innerHTML).
		const isSensitiveWrite = (item.kind === 'write' || item.kind === 'edit') && item.sensitive === true;

		const code = document.createElement('code');
		code.className = 'cmd';
		code.textContent = isSensitiveWrite
			? ('GRAVAR: ' + (item.path || item.cmd || ''))
			: String(item.cmd || '');
		row.appendChild(code);

		if (isSensitiveWrite) {
			const reason = document.createElement('div');
			reason.style.cssText = 'display:inline-block;margin-top:6px;padding:2px 8px;background:#3c2a12;color:#fcd9a3;border:1px solid #6a5735;border-radius:4px;font-size:10px;font-weight:600';
			reason.textContent = '⚠ ARQUIVO SENSÍVEL' + (item.danger ? ': ' + item.danger : '');
			row.appendChild(reason);

			const mainLabel = document.createElement('label');
			mainLabel.className = 'allow';
			const mainCb = document.createElement('input');
			mainCb.type = 'checkbox';
			mainCb.setAttribute('data-role', 'main');
			mainCb.setAttribute('data-idx', String(i));
			mainCb.checked = true;
			mainLabel.appendChild(mainCb);
			mainLabel.appendChild(document.createTextNode(' Gravar'));
			row.appendChild(mainLabel);
		} else {
			if (!item.danger) {
				const alwaysLabel = document.createElement('label');
				alwaysLabel.className = 'allow';
				const alwaysCb = document.createElement('input');
				alwaysCb.type = 'checkbox';
				alwaysCb.setAttribute('data-role', 'always');
				alwaysCb.setAttribute('data-idx', String(i));
				alwaysLabel.appendChild(alwaysCb);
				alwaysLabel.appendChild(document.createTextNode(' Sempre permitir'));
				row.appendChild(alwaysLabel);
			}

			const mainLabel2 = document.createElement('label');
			mainLabel2.className = 'allow';
			const mainCb2 = document.createElement('input');
			mainCb2.type = 'checkbox';
			mainCb2.setAttribute('data-role', 'main');
			mainCb2.setAttribute('data-idx', String(i));
			mainCb2.checked = true;
			mainLabel2.appendChild(mainCb2);
			mainLabel2.appendChild(document.createTextNode(' Executar'));
			row.appendChild(mainLabel2);

			if (item.danger) {
				const d = document.createElement('div');
				d.className = 'run-item-danger-badge';
				d.style.cssText = 'display:inline-block;margin-top:6px;padding:2px 8px;background:#7f1d1d;color:#fecaca;border-radius:4px;font-size:10px;font-weight:700;text-transform:uppercase';
				d.textContent = '⚠ PERIGOSO: ' + item.danger;
				row.appendChild(d);
			}
		}

		list.appendChild(row);
	});
	updateRunBatchCount();
	$('runModal').style.display = 'flex';
}

function hideRunBatchModal() {
	$('runModal').style.display = 'none';
	pendingRunBatch = null;
}

$('runModalDeny').addEventListener('click', () => {
	if (!pendingRunBatch) return;
	window.agentAPI.sendRunBatchResponse({ approved: [], always: [] });
	hideRunBatchModal();
});
$('runModalRun').addEventListener('click', () => {
	if (!pendingRunBatch) return;
	const approved = [], always = [];
	document.querySelectorAll('#runModalList input[data-role="main"]').forEach(cb => {
		if (cb.checked) {
			const idx = parseInt(cb.dataset.idx, 10);
			approved.push(idx);
			// ITEM 11: "Sempre permitir" nunca e' coletado para item sensivel
			// (o main.js tambem filtra como defesa em profundidade).
			const it = pendingRunBatch.items[idx];
			if (it && it.sensitive === true) return;
			const a = document.querySelector('#runModalList input[data-role="always"][data-idx="' + idx + '"]');
			if (a && a.checked) always.push(idx);
		}
	});
	window.agentAPI.sendRunBatchResponse({ approved, always });
	hideRunBatchModal();
});

$('modalProjectCancel').addEventListener('click', () => {
	$('modalProject').style.display = 'none';
});

$('modalProjectSave').addEventListener('click', async () => {
	const name = $('projectNameInput').value.trim();
	const slug = slugify($('projectSlugInput').value || name);
	const root = $('projectRootInput').value.trim();

	if (modalProjectMode === 'editRoot') {
		if (!editingProjectId) return;
		$('modalProject').style.display = 'none';
		const res = await window.projectsAPI.setRoot(editingProjectId, root);
		if (!res.ok) { alert('Erro: ' + res.error); return; }
		const st = await window.projectsAPI.state();
		applyState(st);
		return;
	}

	if (!name) return alert('Digite o nome do projeto.');
	if (!slug) return alert('Digite um slug válido (letras, números e hífen).');

	if (creatingProject) return;
	creatingProject = true;
	$('modalProject').style.display = 'none';
	try {
		const res = await window.projectsAPI.create({ name, slug, projectRoot: root });
		if (!res.ok) { alert('Erro: ' + res.error); return; }
		clearTimeline();
		applyState(res.state);
		try { await restoreHistory(); } catch (e) { }
		if (res.stats) applyStats(res.stats);
	} finally {
		creatingProject = false;
	}
});

$('btnPickRoot').addEventListener('click', async () => {
	try {
		const folder = await window.agentAPI.pickFolder();
		if (folder) $('projectRootInput').value = folder;
	} catch (e) { }
});

$('modalRenameCancel').addEventListener('click', () => { $('modalRename').style.display = 'none'; });
$('modalRenameSave').addEventListener('click', async () => {
	const name = $('renameInput').value.trim();
	if (!name) return alert('Digite um nome.');
	const mode = $('modalRename').dataset.mode;
	const id = $('modalRename').dataset.id;
	if (mode === 'project') {
		const res = await window.projectsAPI.rename(id, name);
		if (!res.ok) return alert('Erro: ' + res.error);
	} else if (mode === 'chat') {
		const res = await window.projectsAPI.renameChat(state.activeProjectId, id, name);
		if (!res.ok) return alert('Erro (local): ' + res.error);
		const remote = $('renameRemote').checked;
		if (remote) {
			showOverlay('Renomeando no DeepSeek…', 'Aguarde.');
			try {
				const r = await window.projectsAPI.renameChatRemote(id, name);
				hideOverlay();
				if (!r || !r.ok) {
					const msg = (r && (r.text || r.error)) || 'erro desconhecido';
					showDiag('Falha ao renomear no DeepSeek: ' + msg, false);
				}
			} catch (e) { hideOverlay(); showDiag('Erro ao renomear no DeepSeek: ' + e.message, false); }
		}
	}
	$('modalRename').style.display = 'none';
	const st = await window.projectsAPI.state();
	applyState(st);
});

$('modalDeleteCancel').addEventListener('click', () => {
	$('modalDelete').style.display = 'none';
	pendingDelete = null;
	$('modalDeleteRemote').disabled = false;
});

$('modalDeleteConfirm').addEventListener('click', async () => {
	if (!pendingDelete) return;
	const remote = !!$('modalDeleteRemote').checked && !$('modalDeleteRemote').disabled;

	if (pendingDelete.type === 'project') {
		if (remote) showOverlay('Removendo projeto…', 'Apagando sessões no DeepSeek. Aguarde.');
		try {
			const res = await window.projectsAPI.delete(pendingDelete.id, remote);
			if (remote) hideOverlay();
			if (!res.ok) {
				if (remote) {
					if (res.needsLogin) {
						hideOverlay();
						showDiag('Sua sessão do DeepSeek expirou. Faça login de novo e tente apagar.', false, {
							actionLabel: 'Abrir DeepSeek',
							onAction: async () => { try { await window.agentAPI.toggleChat(); } catch (e) { } },
							duration: 12000,
						});
					} else {
						overlayError(res.error || 'Falha ao remover projeto.', () => {
							try {
								window.projectsAPI.delete(pendingDelete.id, true).then(r => {
									if (!r.ok) overlayError(r.error || 'Falha.', null);
									else { hideOverlay(); clearTimeline(); applyState(r.state); if (r.stats) applyStats(r.stats); }
								});
							} catch (e) { }
						});
					}
				} else { alert('Erro: ' + res.error); }
				$('modalDelete').style.display = 'none';
				pendingDelete = null;
				$('modalDeleteRemote').disabled = false;
				return;
			}
			clearTimeline();
			applyState(res.state);
			try { await restoreHistory(); } catch (e) { }
			if (res.stats) applyStats(res.stats);
		} catch (e) { if (remote) hideOverlay(); alert('Erro: ' + e.message); }
		$('modalDelete').style.display = 'none';
		pendingDelete = null;
		$('modalDeleteRemote').disabled = false;
		return;
	}

	const uuid = pendingDelete.id;
	const wasActive = (uuid === state.activeChatUuid);
	if (remote) showOverlay('Removendo sessão…', 'Apagando no DeepSeek. Aguarde.');

	try {
		const res = await window.projectsAPI.deleteChat(state.activeProjectId, uuid, remote);
		if (remote) hideOverlay();
		if (!res.ok) {
			if (remote) {
				if (res.needsLogin) {
					hideOverlay();
					showDiag('Sua sessão do DeepSeek expirou. Faça login de novo e tente apagar.', false, {
						actionLabel: 'Abrir DeepSeek',
						onAction: async () => { try { await window.agentAPI.toggleChat(); } catch (e) { } },
						duration: 12000,
					});
				} else {
					overlayError(res.error || 'Falha ao remover sessão.', () => {
						try {
							window.projectsAPI.deleteChat(state.activeProjectId, uuid, true).then(r => {
								if (!r.ok) overlayError(r.error || 'Falha.', null);
								else { hideOverlay(); if (wasActive) clearTimeline(); applyState(r.state); if (r.stats) applyStats(r.stats); }
							});
						} catch (e) { }
					});
				}
			} else { alert('Erro: ' + res.error); }
			$('modalDelete').style.display = 'none';
			pendingDelete = null;
			$('modalDeleteRemote').disabled = false;
			return;
		}
		if (res.needsLogin) {
			showDiag('Sua sessão do DeepSeek expirou. Faça login de novo e tente apagar.', false, {
				actionLabel: 'Abrir DeepSeek',
				onAction: async () => { try { await window.agentAPI.toggleChat(); } catch (e) { } },
				duration: 12000,
			});
		}
		if (wasActive) clearTimeline();
		applyState(res.state);
		if (wasActive) { try { await restoreHistory(); } catch (e) { } }
		if (res.stats) applyStats(res.stats);
	} catch (e) { if (remote) hideOverlay(); alert('Erro: ' + e.message); }
	$('modalDelete').style.display = 'none';
	pendingDelete = null;
	$('modalDeleteRemote').disabled = false;
});

$('btnAddProject').addEventListener('click', openNewProject);
$('btnOpenDeepSeek').addEventListener('click', async () => {
	try {
		const res = await window.agentAPI.toggleChat();
		if (res && typeof res.visible === 'boolean') applyChatWindowState(res.visible);
	} catch (e) { showDiag('Erro ao alternar DeepSeek: ' + e.message, false); }
});
$('btnCompactNow').addEventListener('click', doCompact);
$('compactBannerBtn').addEventListener('click', doCompact);
$('gitBannerBtn').addEventListener('click', async () => {
	const project = state.projects.find(p => p.id === state.activeProjectId);
	if (!project || state.running) return;
	const btn = $('gitBannerBtn');
	btn.disabled = true;
	try {
		const r = await window.agentAPI.gitCreateBranch(project.projectRoot, project.slug);
		if (!r || !r.ok) showDiag('Falha ao criar a branch: ' + ((r && r.error) || 'erro desconhecido'), false);
	} catch (e) {
		showDiag('Erro ao criar a branch: ' + e.message, false);
	}
	btn.disabled = false;
	await refreshGitBanner();
});
window.addEventListener('focus', refreshGitBanner);
window.addEventListener('focus', refreshCommitsPanel);
$('btnCommits').addEventListener('click', () => setCommitsOpen(!state.commitsOpen));
$('btnCommitsClose').addEventListener('click', () => setCommitsOpen(false));
$('btnCommitsRefresh').addEventListener('click', refreshCommitsPanel);
$('modalRestoreCancel').addEventListener('click', () => {
	$('modalRestore').style.display = 'none';
	pendingRestore = null;
});
$('modalRestoreConfirm').addEventListener('click', async () => {
	if (!pendingRestore || state.running) return;
	const pr = pendingRestore;
	const btn = $('modalRestoreConfirm');
	btn.disabled = true;
	btn.textContent = '⏳ Restaurando…';
	try {
		const r = await window.agentAPI.gitRestore(pr.project.projectRoot, pr.project.slug, pr.commit.hash);
		if (r && r.ok) showDiag('Restaurado para ' + pr.commit.short + (r.hash ? ' (novo commit ' + r.hash + ')' : ''), true);
		else showDiag('Falha ao restaurar: ' + ((r && r.error) || 'erro desconhecido'), false);
	} catch (e) {
		showDiag('Erro ao restaurar: ' + e.message, false);
	}
	btn.disabled = false;
	btn.textContent = '↩ Restaurar';
	$('modalRestore').style.display = 'none';
	pendingRestore = null;
	try { closeDiffModal(); } catch (e) { }
	await refreshCommitsPanel();
});
$('btnCommitsMerge').addEventListener('click', openMergeModal);
$('modalMergeCancel').addEventListener('click', () => {
	$('modalMerge').style.display = 'none';
	pendingMerge = null;
});
$('modalMergeConfirm').addEventListener('click', async () => {
	if (!pendingMerge || state.running) return;
	const pm = pendingMerge;
	const target = $('modalMergeSelect').value;
	if (!target) return;
	const btn = $('modalMergeConfirm');
	btn.disabled = true;
	btn.textContent = '⏳ Aplicando…';
	try {
		const r = await window.agentAPI.gitMerge(pm.project.projectRoot, pm.project.slug, target);
		if (r && r.ok) showDiag('Merge aplicado em "' + target + '"' + (r.hash ? ' (commit ' + r.hash + ')' : '') + '. A branch do agente foi zerada.', true);
		else showDiag('Falha no merge: ' + ((r && r.error) || 'erro desconhecido'), false);
	} catch (e) {
		showDiag('Erro no merge: ' + e.message, false);
	}
	btn.disabled = false;
	btn.textContent = 'Aplicar';
	$('modalMerge').style.display = 'none';
	pendingMerge = null;
	await refreshCommitsPanel();
});
$('sessionFilter').addEventListener('input', renderChats);
$('btnSend').addEventListener('click', runTask);
$('btnStop').addEventListener('click', stopTask);
$('messageInput').addEventListener('keydown', (e) => {
	if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); runTask(); }
});
document.addEventListener('click', (e) => {
	const wrap = $('sessionsWrap');
	if (wrap && wrap.open && !wrap.contains(e.target)) wrap.open = false;
});

document.addEventListener('click', async (e) => {
	const btn = e.target && e.target.closest ? e.target.closest('.code-copy') : null;
	if (!btn) return;
	const box = btn.closest('.code-block');
	const pre = box ? box.querySelector('pre') : null;
	if (!pre) return;
	try {
		await navigator.clipboard.writeText(pre.textContent || '');
		btn.textContent = 'Copiado \u2713';
	} catch (err) {
		btn.textContent = 'Falhou';
	}
	setTimeout(() => { btn.textContent = 'Copiar'; }, 1500);
});

// $('diffTabCommit').addEventListener('click', () => { setDiffMode('commit'); });
// $('diffTabCurrent').addEventListener('click', () => { setDiffMode('current'); });
$('diffClose').addEventListener('click', () => { closeDiffModal(); });
$('diffRestore').addEventListener('click', () => {
	if (!diffState) return;
	const btn = $('diffRestore');
	if (btn && btn.disabled) return;
	openRestoreModal(diffState.project, diffState.commit, diffState.dirty);
});
document.addEventListener('keydown', (e) => {
	if (e.key !== 'Escape') return;
	const diffOpen = $('modalDiff') && $('modalDiff').style.display === 'flex';
	const restoreOpen = $('modalRestore') && $('modalRestore').style.display === 'flex';
	if (diffOpen && !restoreOpen) closeDiffModal();
});

window.agentAPI.onCommand((cmd) => {
	const statusText = {
		read: 'Lendo ' + (cmd.arg || ''),
		edit: 'Editando ' + (cmd.arg || ''),
		write: 'Criando ' + (cmd.arg || ''),
		run: 'Executando comando',
		ls: 'Listando ' + (cmd.arg || ''),
		glob: 'Buscando arquivos',
		grep: 'Buscando texto',
	}[cmd.type];
	if (statusText) updateLiveStatus(statusText);
	addCommandCard(cmd);
});

window.agentAPI.onResult((r) => {
	if (r && r.type !== 'message' && document.querySelector('.live-status')) {
		updateLiveStatus('Analisando resposta');
	}
	addResultCard(r);
});

window.agentAPI.onStats((s) => { applyStats(s); });
window.agentAPI.onStream((d) => { updateStreamBox(d && d.text); });
window.agentAPI.onChatWindowState((data) => { applyChatWindowState(data.visible); });
window.agentAPI.onRunBatchRequest((data) => {
	if (!data || !Array.isArray(data.items)) return;
	showRunBatchModal(data.items);
});
window.agentAPI.onLog((msg) => {
	if (!msg) return;
	const internalPrefixes = ['[main]', 'compact:', 'runAgent ', 'turno ', 'executando ', 'enviando ', 'resposta recebida', 'turn0 tamanho', 'RUNs aguardando', 'confirmado:', 'RUN sempre-aprovado', 'askAndLog:', 'abortado ', 'abort solicitado', 'DONE'];
	if (internalPrefixes.some(p => msg.indexOf(p) === 0)) {
		console.log('[agent log]', msg);
		return;
	}
	if (msg.startsWith('❌') || msg.indexOf('ERRO') !== -1) showDiag(msg, false);
	else if (msg.startsWith('✅')) showDiag(msg, true);
	else console.log('[agent]', msg);
});

window.projectsAPI.onChanged((st) => { applyState(st); });

// ============================================================
// Persistencia e restauracao do historico visual
// ============================================================
async function persistTimeline() {
	const projectId = state.activeProjectId;
	const chatId = state.activeChatUuid;
	if (!projectId || !chatId) return;
	if (!window.historyAPI) return;

	const content = $('chatContent');
	if (!content) return;

	const entries = [];
	const nodes = [];
	const children = content.children;
	for (let i = 0; i < children.length; i++) {
		const node = children[i];
		if (!node || node.dataset.hist === '1') continue;
		if (node.id === 'emptyState') continue;
		if (node.classList.contains('compacting')) continue;
		if (node.classList.contains('live-status')) continue;
		if (node.classList.contains('stream-box')) continue;
		if (node.classList.contains('history-more')) continue;

		let kind = 'assistant';
		if (node.classList.contains('msg-row') && node.classList.contains('user')) kind = 'user';
		else if (node.classList.contains('activity')) kind = 'event';
		else if (node.classList.contains('session-marker')) kind = 'system';
		else if (node.classList.contains('msg-row')) kind = 'assistant';
		else continue;

		const clone = node.cloneNode(true);
		const reviewBtn = clone.querySelector('.review-btn');
		if (reviewBtn) reviewBtn.remove();
		const detailsList = clone.querySelectorAll('details[open]');
		for (const d of detailsList) d.removeAttribute('open');

		entries.push({ t: Date.now(), kind, html: clone.outerHTML });
		nodes.push(node);
	}

	if (!entries.length) return;

	try {
		const res = await window.historyAPI.append(projectId, chatId, entries);
		if (res && res.ok) {
			for (const node of nodes) node.dataset.hist = '1';
		}
	} catch (e) { }
}

// Limpeza minima (sem allowlist) para restaurar HTML ja gravado.
function cleanHistoryNode(node) {
	if (!node || node.nodeType !== 1) return node;
	const bad = node.querySelectorAll('script, iframe, object, embed');
	for (const el of Array.from(bad)) el.remove();
	const all = [node].concat(Array.from(node.querySelectorAll('*')));
	for (const el of all) {
		if (el.nodeType !== 1) continue;
		for (const attr of Array.from(el.attributes)) {
			const name = attr.name.toLowerCase();
			if (name.indexOf('on') === 0) { el.removeAttribute(attr.name); continue; }
			if (name === 'href' || name === 'src') {
				const val = (el.getAttribute(attr.name) || '').trim().toLowerCase();
				if (val.indexOf('javascript:') === 0) el.removeAttribute(attr.name);
			}
		}
	}
	return node;
}

function entryToNode(html) {
	const template = document.createElement('template');
	template.innerHTML = String(html || '');
	const node = template.content.firstElementChild;
	if (!node) return null;
	return cleanHistoryNode(node);
}

async function restoreHistory() {
	const projectId = state.activeProjectId;
	const chatId = state.activeChatUuid;
	if (!projectId || !chatId) return;
	if (!window.historyAPI) return;

	try {
		const res = await window.historyAPI.readLast(projectId, chatId);
		if (!res || !Array.isArray(res.entries) || res.entries.length === 0) return;

		ensureEmptyRemoved();
		const content = $('chatContent');
		for (const entry of res.entries) {
			const node = entryToNode(entry.html);
			if (!node) continue;
			node.dataset.hist = '1';
			content.appendChild(node);
		}
		scrollToBottom();

		state.histPage = res.page || 1;
		state.histTotal = res.totalPages || 1;

		if (state.histTotal > 1 && state.histPage > 1) {
			insertHistoryMoreButton();
		}
	} catch (e) { }
}

function insertHistoryMoreButton() {
	const content = $('chatContent');
	if (!content) return;
	if (content.querySelector('.history-more')) return;
	const btn = document.createElement('button');
	btn.type = 'button';
	btn.className = 'history-more';
	btn.textContent = 'Carregar mensagens anteriores';
	btn.addEventListener('click', loadPreviousHistoryPage);
	content.insertBefore(btn, content.firstChild);
}

async function loadPreviousHistoryPage() {
	const projectId = state.activeProjectId;
	const chatId = state.activeChatUuid;
	if (!projectId || !chatId) return;
	if (!window.historyAPI) return;
	const btn = document.querySelector('#chatContent .history-more');
	if (!btn) return;
	const targetPage = state.histPage - 1;
	if (targetPage < 1) { btn.remove(); return; }

	try {
		const res = await window.historyAPI.readPage(projectId, chatId, targetPage);
		if (!res || !Array.isArray(res.entries) || res.entries.length === 0) {
			btn.remove();
			return;
		}
		const content = $('chatContent');
		const timeline = $('timeline');
		const prevHeight = timeline ? timeline.scrollHeight : 0;

		for (const entry of res.entries) {
			const node = entryToNode(entry.html);
			if (!node) continue;
			node.dataset.hist = '1';
			content.insertBefore(node, btn);
		}

		state.histPage = targetPage;
		if (state.histPage <= 1) btn.remove();

		if (timeline) {
			const newHeight = timeline.scrollHeight;
			timeline.scrollTop = timeline.scrollTop + (newHeight - prevHeight);
		}
	} catch (e) { }
}


// ============================================================
// LICENÇA — barra no topo + modal (estado vem do main via licenseAPI)
// ============================================================
(function () {
	if (!window.licenseAPI) return;

	const L = window.licenseAPI;
	const el = {
		modal: $('licenseModal'),
		caption: $('licCaption'),
		bar: $('licBar'),
		barText: $('licBarText'),
		barFill: $('licBarFill'),
		barOpen: $('licBarOpen'),
		pay: $('licPay'),
		stepValue: $('licStepValue'),
		stepPix: $('licStepPix'),
		valueLabel: $('licValueLabel'),
		value: $('licValue'),
		name: $('licName'),
		cpf: $('licCpf'),
		generate: $('licGenerate'),
		qr: $('licQr'),
		payload: $('licPayload'),
		copy: $('licCopy'),
		payStatus: $('licPayStatus'),
		changeValue: $('licChangeValue'),
		code: $('licCode'),
		activate: $('licActivate'),
		error: $('licError'),
		close: $('licClose'),
	};

	let current = null;
	let deadlineAt = 0;
	let tickTimer = null;
	let cobrancaId = null;
	let pollTimer = null;
	let polling = false;

	function fmt(ms) {
		const s = Math.ceil(ms / 1000);
		return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
	}

	function setError(msg) {
		el.error.textContent = msg || '';
		el.error.style.display = msg ? 'block' : 'none';
	}

	function captionFor(s) {
		if (s.reason === 'trial_expired') return 'Seu teste gratuito de 7 dias terminou. Libere o app com uma ajuda única da comunidade para continuar.';
		if (s.phase === 'trial') return 'Você está no teste gratuito. Se quiser, já pode liberar o app com uma ajuda única da comunidade.';
		if (s.phase === 'locked') return 'Tempo de uso esgotado. As tarefas ficam bloqueadas até o app ser liberado.';
		if (s.reason === 'offline') return 'Sem conexão com o servidor de licenças. Tentando reconectar automaticamente…';
		if (s.reason === 'invalid') return s.message || 'Esta licença não é mais válida neste computador.';
		return 'Libere o app com uma ajuda única da comunidade. Pagou, o PIX bateu, o app é liberado.';
	}

	function tick() {
		if (!current || current.phase !== 'grace') return;
		const rem = Math.max(0, deadlineAt - performance.now());
		el.barFill.style.width = (100 - rem / current.graceMs * 100) + '%';
		const base = current.reason === 'offline' ? 'Sem conexão com o servidor de licenças' : 'App sem licença';
		el.barText.textContent = base + ' · tempo restante: ' + fmt(rem);
	}

	function startTick() {
		if (tickTimer) return;
		tickTimer = setInterval(tick, 250);
	}

	function stopTick() {
		if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
	}

	function stopPolling() {
		if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
		polling = false;
	}

	function resetPix() {
		stopPolling();
		cobrancaId = null;
		el.stepPix.style.display = 'none';
		el.stepValue.style.display = 'flex';
		el.payStatus.textContent = 'Aguardando pagamento…';
	}

	async function pollOnce() {
		if (polling || !cobrancaId) return;
		polling = true;
		try {
			const r = await L.checkoutStatus(cobrancaId);
			if (r && r.status === 'RECEIVED' && r.unlocked) {
				stopPolling();
				el.payStatus.textContent = '✅ Pagamento confirmado! App liberado.';
			} else if (r && (r.status === 'NOT_FOUND' || r.status === 'ERROR')) {
				resetPix();
				setError((r && r.error) || 'Não foi possível confirmar o pagamento. Gere o PIX novamente.');
			}
		} catch (e) { /* tenta de novo no próximo ciclo */ }
		polling = false;
	}

	function startPolling() {
		stopPolling();
		pollTimer = setInterval(pollOnce, 3000);
	}

	function render(s) {
		if (!s) return;
		current = s;

		const inGate = s.phase === 'grace' || s.phase === 'locked' || s.phase === 'trial';
		el.modal.style.display = (s.showModal && inGate) ? 'flex' : 'none';

		if (s.phase === 'valid') {
			stopTick();
			resetPix();
			setError('');
			el.bar.style.display = 'none';
			document.body.classList.remove('lic-on');
			return;
		}

		el.caption.textContent = captionFor(s);
		el.valueLabel.textContent = 'Valor da ajuda (mínimo R$ ' + s.minValue + ')';
		el.value.min = String(s.minValue);
		if (!el.value.value || Number(el.value.value) < s.minValue) el.value.value = String(s.minValue);
		el.pay.style.display = s.reason === 'offline' ? 'none' : 'flex';
		el.close.textContent = s.phase === 'locked' ? 'Fechar e continuar (1 min)' : 'Fechar';

		if (inGate) {
			el.bar.style.display = 'block';
			document.body.classList.add('lic-on');
		}

		if (s.phase === 'grace') {
			deadlineAt = performance.now() + s.remainingMs;
			el.bar.classList.remove('locked');
			tick();
			startTick();
		} else if (s.phase === 'trial') {
			stopTick();
			el.bar.classList.remove('locked');
			const rem = s.trialRemainingMs;
			const days = Math.ceil(rem / 86400000);
			el.barText.textContent = 'Teste gratuito · ' + (rem < 86400000 ? 'menos de 24h restantes' : (days === 1 ? '1 dia restante' : days + ' dias restantes'));
			el.barFill.style.width = Math.min(100, Math.max(0, 100 - rem / s.trialTotalMs * 100)) + '%';
		} else if (s.phase === 'locked') {
			stopTick();
			el.bar.classList.add('locked');
			el.barText.textContent = 'Bloqueado: tarefas desativadas até liberar o app';
		} else {
			stopTick();
			el.bar.style.display = 'none';
			document.body.classList.remove('lic-on');
		}
	}

	el.generate.addEventListener('click', async () => {
		const min = current ? current.minValue : 15;
		const valor = Number(el.value.value);
		if (!isFinite(valor) || valor < min) {
			setError('O valor mínimo é R$ ' + min + ',00');
			return;
		}
		const nome = el.name.value.trim();
		const cpf = el.cpf.value.replace(/\D/g, '');
		if (nome.length < 3) { setError('Informe seu nome completo.'); return; }
		if (cpf.length !== 11) { setError('Informe um CPF válido (11 dígitos).'); return; }
		setError('');
		el.generate.disabled = true;
		try {
			const r = await L.checkout(valor, { nome: nome, cpf: cpf });
			if (!r || !r.ok) {
				setError((r && r.error) || 'Falha ao gerar o PIX.');
				return;
			}
			cobrancaId = r.cobranca_id;
			el.qr.src = r.pix_qrcode;
			el.payload.value = r.pix_copia_cola;
			el.payStatus.textContent = 'Aguardando pagamento…';
			el.stepValue.style.display = 'none';
			el.stepPix.style.display = 'flex';
			startPolling();
		} catch (e) {
			setError('Falha ao gerar o PIX.');
		} finally {
			el.generate.disabled = false;
		}
	});

	el.changeValue.addEventListener('click', resetPix);

	el.copy.addEventListener('click', async () => {
		try {
			await navigator.clipboard.writeText(el.payload.value);
		} catch (e) {
			el.payload.select();
			try { document.execCommand('copy'); } catch (_) { }
		}
		el.copy.textContent = 'Copiado ✓';
		setTimeout(() => { el.copy.textContent = 'Copiar'; }, 1500);
	});

	el.activate.addEventListener('click', async () => {
		const code = el.code.value.trim();
		if (!code) { setError('Informe o código de ativação.'); return; }
		setError('');
		el.activate.disabled = true;
		try {
			const r = await L.activate(code);
			if (!r || !r.ok) setError((r && r.error) || 'Falha na ativação.');
		} catch (e) {
			setError('Falha na ativação.');
		} finally {
			el.activate.disabled = false;
		}
	});

	el.close.addEventListener('click', () => { L.dismiss(); });
	el.barOpen.addEventListener('click', () => { L.open(); });

	L.onState(render);
	L.getState().then(render).catch(() => { });
})();