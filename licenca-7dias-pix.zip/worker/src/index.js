// src/index.js — Worker de licenciamento: teste grátis + PIX (Asaas) + ativação + validação.
// Binding D1: env.BIND_DEEPSEEK. Secrets: ver wrangler.toml.

// ══════════════════════════════════════════════════
// CONFIG
// ══════════════════════════════════════════════════
const TRIAL_DAYS         = 7;
const MAX_TRIALS_PER_IP  = 5;                        // por janela abaixo (CGNAT: não seja muito baixo)
const TRIAL_IP_WINDOW_MS = 30 * 24 * 3600 * 1000;
const MIN_VALUE          = 15;                       // R$ (mesmo valor do app)
const MAX_VALUE          = 5000;
const MAX_PENDING_PER_FP = 10;                       // cobranças PENDING por fingerprint na última hora

const isSandbox  = (env) => String(env.ASAAS_SANDBOX).toLowerCase() === 'true';
const asaasBase  = (env) => isSandbox(env) ? 'https://sandbox.asaas.com' : 'https://www.asaas.com';
const asaasKey   = (env) => isSandbox(env) ? env.ASAAS_KEY_SANDBOX : env.ASAAS_KEY_PRODUCAO;
const webhookTok = (env) => isSandbox(env) ? env.ASAAS_WEBHOOK_TOKEN_SANDBOX : env.ASAAS_WEBHOOK_TOKEN;

// ══════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });
}

async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}

function generateToken() { return crypto.randomUUID(); }

// DSK-XXXX-XXXX-XXXX (sem 0/O/1/I/L pra ninguém errar ao digitar)
function generateActivationCode() {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  const chars = Array.from(bytes, (b) => alphabet[b % alphabet.length]);
  return 'DSK-' + [0, 4, 8].map((i) => chars.slice(i, i + 4).join('')).join('-');
}

const isFingerprint = (v) => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);

function validCpf(raw) {
  const c = String(raw || '').replace(/\D/g, '');
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;
  for (const n of [9, 10]) {
    let sum = 0;
    for (let i = 0; i < n; i++) sum += Number(c[i]) * (n + 1 - i);
    if (((sum * 10) % 11) % 10 !== Number(c[n])) return false;
  }
  return true;
}

function asaasHeaders(env) {
  return { 'Content-Type': 'application/json', access_token: asaasKey(env), 'User-Agent': 'opendeepseek-license/1.0' };
}

const daysLeft = (expiresAt) => Math.max(0, Math.ceil((expiresAt - Date.now()) / 86400000));

// ══════════════════════════════════════════════════
// POST /trial   { fingerprint }
// 1 teste de 7 dias por fingerprint. Idempotente: se o app perder o token, recebe o mesmo.
// ══════════════════════════════════════════════════
async function handleTrial(request, env) {
  const body = await readJson(request);
  if (!body || !isFingerprint(body.fingerprint)) return json({ error: 'fingerprint inválido' }, 400);
  const fp = body.fingerprint;
  const now = Date.now();

  let trial = await env.BIND_DEEPSEEK.prepare('SELECT * FROM trials WHERE fingerprint = ?').bind(fp).first();

  if (!trial) {
    const ip = request.headers.get('CF-Connecting-IP') || '';
    if (ip) {
      const { c } = await env.BIND_DEEPSEEK
        .prepare('SELECT COUNT(*) AS c FROM trials WHERE ip = ? AND started_at > ?')
        .bind(ip, now - TRIAL_IP_WINDOW_MS).first();
      if (c >= MAX_TRIALS_PER_IP) {
        return json({ error: 'Muitos testes gratuitos iniciados nesta rede. Libere o app para continuar.', trial_used: true }, 429);
      }
    }
    // INSERT OR IGNORE: duas requisições simultâneas não geram dois testes
    await env.BIND_DEEPSEEK
      .prepare('INSERT OR IGNORE INTO trials (fingerprint, token, ip, started_at, expires_at) VALUES (?, ?, ?, ?, ?)')
      .bind(fp, generateToken(), ip, now, now + TRIAL_DAYS * 86400000).run();
    trial = await env.BIND_DEEPSEEK.prepare('SELECT * FROM trials WHERE fingerprint = ?').bind(fp).first();
  }

  if (trial.expires_at <= now) {
    return json({ error: `Seu teste gratuito de ${TRIAL_DAYS} dias terminou.`, trial_used: true }, 403);
  }
  return json({ token: trial.token, plan: 'trial', expires_at: trial.expires_at, days_left: daysLeft(trial.expires_at) });
}

// ══════════════════════════════════════════════════
// POST /activate   { activation_code, fingerprint }
// ══════════════════════════════════════════════════
async function handleActivate(request, env) {
  const body = await readJson(request);
  if (!body || !body.activation_code || !isFingerprint(body.fingerprint)) {
    return json({ error: 'activation_code e fingerprint são obrigatórios' }, 400);
  }
  const code = String(body.activation_code).trim().toUpperCase();
  const fingerprint = body.fingerprint;

  const license = await env.BIND_DEEPSEEK
    .prepare('SELECT * FROM licenses WHERE UPPER(activation_code) = ?').bind(code).first();

  if (!license) return json({ error: 'Código de ativação inválido' }, 404);
  if (license.status === 'blocked') return json({ error: 'Licença bloqueada' }, 403);

  if (license.status === 'active') {
    if (license.fingerprint !== fingerprint) {
      return json({ error: 'Esta licença já está ativada em outro dispositivo' }, 403);
    }
    await env.BIND_DEEPSEEK
      .prepare("UPDATE licenses SET last_validated_at = datetime('now') WHERE id = ?").bind(license.id).run();
    return json({ token: license.token });
  }

  const token = generateToken();
  // "AND status = 'pending'" garante que só uma ativação vença em caso de corrida
  const r = await env.BIND_DEEPSEEK
    .prepare(`UPDATE licenses
              SET fingerprint = ?, token = ?, status = 'active',
                  activated_at = datetime('now'), last_validated_at = datetime('now')
              WHERE id = ? AND status = 'pending'`)
    .bind(fingerprint, token, license.id).run();
  if (!r.meta.changes) return json({ error: 'Esta licença acabou de ser ativada em outro dispositivo' }, 409);

  return json({ token });
}

// ══════════════════════════════════════════════════
// POST /validate   { fingerprint, token }   -> licença paga OU teste
// ══════════════════════════════════════════════════
async function handleValidate(request, env) {
  const body = await readJson(request);
  if (!body || !body.fingerprint || !body.token) return json({ error: 'fingerprint e token são obrigatórios' }, 400);
  const { fingerprint, token } = body;

  const license = await env.BIND_DEEPSEEK.prepare('SELECT * FROM licenses WHERE token = ?').bind(token).first();
  if (license) {
    if (license.status !== 'active' || license.fingerprint !== fingerprint) {
      return json({ valid: false, error: 'Licença inválida neste computador' }, 403);
    }
    await env.BIND_DEEPSEEK
      .prepare("UPDATE licenses SET last_validated_at = datetime('now') WHERE id = ?").bind(license.id).run();
    return json({ valid: true, plan: 'paid' });
  }

  const trial = await env.BIND_DEEPSEEK.prepare('SELECT * FROM trials WHERE token = ?').bind(token).first();
  if (trial && trial.fingerprint === fingerprint) {
    if (trial.expires_at <= Date.now()) {
      return json({ valid: false, trial_expired: true, error: `Seu teste gratuito de ${TRIAL_DAYS} dias terminou.` }, 403);
    }
    return json({ valid: true, plan: 'trial', expires_at: trial.expires_at, days_left: daysLeft(trial.expires_at) });
  }

  return json({ valid: false }, 403);
}

// ══════════════════════════════════════════════════
// POST /checkout   { valor, fingerprint, nome, cpf }
// Cria cliente + cobrança PIX no Asaas.
// ══════════════════════════════════════════════════
async function handleCheckout(request, env) {
  const body = await readJson(request);
  if (!body) return json({ error: 'Body inválido' }, 400);

  const valor = Math.round(Number(body.valor) * 100) / 100;
  const nome = String(body.nome || '').trim();
  const cpf = String(body.cpf || '').replace(/\D/g, '');

  if (!isFingerprint(body.fingerprint)) return json({ error: 'fingerprint inválido' }, 400);
  if (!isFinite(valor) || valor < MIN_VALUE) return json({ error: `O valor mínimo é R$ ${MIN_VALUE},00` }, 400);
  if (valor > MAX_VALUE) return json({ error: `O valor máximo é R$ ${MAX_VALUE},00` }, 400);
  if (nome.length < 3) return json({ error: 'Informe seu nome completo' }, 400);
  if (!validCpf(cpf)) return json({ error: 'CPF inválido' }, 400);

  const { c } = await env.BIND_DEEPSEEK
    .prepare("SELECT COUNT(*) AS c FROM payments WHERE fingerprint = ? AND status = 'PENDING' AND created_at > ?")
    .bind(body.fingerprint, Date.now() - 3600000).first();
  if (c >= MAX_PENDING_PER_FP) return json({ error: 'Muitas cobranças geradas. Aguarde um pouco e tente de novo.' }, 429);

  // 1) cliente (busca por CPF, senão cria)
  let customerId;
  try {
    const found = await (await fetch(`${asaasBase(env)}/api/v3/customers?cpfCnpj=${cpf}`, { headers: asaasHeaders(env) })).json();
    if (found.data && found.data.length) {
      customerId = found.data[0].id;
    } else {
      const created = await (await fetch(`${asaasBase(env)}/api/v3/customers`, {
        method: 'POST', headers: asaasHeaders(env),
        body: JSON.stringify({ name: nome, cpfCnpj: cpf, notificationDisabled: true }),
      })).json();
      if (created.errors || !created.id) return json({ error: 'Não foi possível criar o cliente no Asaas' }, 502);
      customerId = created.id;
    }
  } catch { return json({ error: 'Erro ao conectar no Asaas (cliente)' }, 502); }

  // 2) cobrança PIX
  let cobranca;
  try {
    cobranca = await (await fetch(`${asaasBase(env)}/api/v3/payments`, {
      method: 'POST', headers: asaasHeaders(env),
      body: JSON.stringify({
        customer: customerId,
        billingType: 'PIX',
        value: valor,
        dueDate: new Date().toISOString().split('T')[0],
        description: 'OpenDeepSeek — licença',
        notificationDisabled: true,
      }),
    })).json();
    if (cobranca.errors || !cobranca.id) return json({ error: 'Não foi possível criar a cobrança no Asaas' }, 502);
  } catch { return json({ error: 'Erro ao conectar no Asaas (cobrança)' }, 502); }

  // 3) QR Code
  let pix;
  try {
    pix = await (await fetch(`${asaasBase(env)}/api/v3/payments/${cobranca.id}/pixQrCode`, { headers: asaasHeaders(env) })).json();
    if (!pix.payload) return json({ error: 'Não foi possível gerar o QR Code PIX' }, 502);
  } catch { return json({ error: 'Erro ao buscar o QR Code PIX' }, 502); }

  // 4) grava (não guardamos CPF: o Asaas já guarda)
  await env.BIND_DEEPSEEK
    .prepare('INSERT INTO payments (cobranca_id, fingerprint, customer_id, nome, valor, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .bind(cobranca.id, body.fingerprint, customerId, nome, valor, 'PENDING', Date.now()).run();

  return json({
    cobranca_id: cobranca.id,
    valor,
    pix_qrcode: 'data:image/png;base64,' + pix.encodedImage,
    pix_copia_cola: pix.payload,
  }, 201);
}

// ══════════════════════════════════════════════════
// Libera o pagamento: gera o código de ativação UMA vez (webhook e polling podem chegar juntos)
// ══════════════════════════════════════════════════
async function liberarPagamento(env, cobrancaId) {
  const db = env.BIND_DEEPSEEK;
  const p = await db.prepare('SELECT * FROM payments WHERE cobranca_id = ?').bind(cobrancaId).first();
  if (!p) return null;
  if (p.status === 'RECEIVED' && p.activation_code) return p.activation_code;

  const code = generateActivationCode();
  await db.batch([
    db.prepare("UPDATE payments SET status = 'RECEIVED', activation_code = ?, paid_at = ? WHERE cobranca_id = ? AND status != 'RECEIVED'")
      .bind(code, Date.now(), cobrancaId),
    // só insere se ESTE código foi o que ficou gravado (quem perde a corrida não cria licença)
    db.prepare("INSERT INTO licenses (activation_code, status) SELECT ?, 'pending' WHERE EXISTS (SELECT 1 FROM payments WHERE cobranca_id = ? AND activation_code = ?)")
      .bind(code, cobrancaId, code),
  ]);

  const after = await db.prepare('SELECT activation_code FROM payments WHERE cobranca_id = ?').bind(cobrancaId).first();
  return after ? after.activation_code : null;
}

// ══════════════════════════════════════════════════
// GET /checkout/:id/status?fingerprint=...
// ══════════════════════════════════════════════════
async function handleCheckoutStatus(cobrancaId, url, env) {
  const fp = url.searchParams.get('fingerprint') || '';
  const p = await env.BIND_DEEPSEEK.prepare('SELECT * FROM payments WHERE cobranca_id = ?').bind(cobrancaId).first();

  // só quem gerou a cobrança (mesmo fingerprint) enxerga o código
  if (!p || p.fingerprint !== fp) return json({ status: 'NOT_FOUND' }, 404);

  if (p.status === 'RECEIVED') return json({ status: 'RECEIVED', activation_code: p.activation_code });

  // webhook pode atrasar: confirma direto no Asaas
  try {
    const data = await (await fetch(`${asaasBase(env)}/api/v3/payments/${cobrancaId}`, { headers: asaasHeaders(env) })).json();
    if (data.status === 'RECEIVED' || data.status === 'CONFIRMED') {
      const code = await liberarPagamento(env, cobrancaId);
      if (code) return json({ status: 'RECEIVED', activation_code: code });
    }
    if (data.status === 'OVERDUE' || data.status === 'DELETED' || data.status === 'REFUNDED') {
      return json({ status: 'ERROR', error: 'Este PIX expirou ou foi cancelado. Gere outro.' });
    }
  } catch { /* cai em PENDING; o app tenta de novo */ }

  return json({ status: 'PENDING' });
}

// ══════════════════════════════════════════════════
// POST /webhook/asaas
// ══════════════════════════════════════════════════
async function handleWebhook(request, env) {
  const expected = webhookTok(env);
  if (!expected || request.headers.get('asaas-access-token') !== expected) return json({ error: 'Unauthorized' }, 401);

  const body = await readJson(request);
  if (!body) return json({ error: 'Body inválido' }, 400);

  if (body.event !== 'PAYMENT_RECEIVED' && body.event !== 'PAYMENT_CONFIRMED') return json({ ok: true, ignored: true });

  const cobrancaId = body.payment && body.payment.id;
  if (!cobrancaId) return json({ ok: true, ignored: true });

  // Sempre 200: o Asaas pausa a fila do webhook se receber erro repetido
  await liberarPagamento(env, cobrancaId);
  return json({ ok: true });
}

// ══════════════════════════════════════════════════
// ROTEADOR
// ══════════════════════════════════════════════════
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const method = request.method;
    const path = url.pathname.replace(/\/$/, '') || '/';

    try {
      if (method === 'POST' && path === '/trial')          return await handleTrial(request, env);
      if (method === 'POST' && path === '/activate')       return await handleActivate(request, env);
      if (method === 'POST' && path === '/validate')       return await handleValidate(request, env);
      if (method === 'POST' && path === '/checkout')       return await handleCheckout(request, env);
      if (method === 'POST' && path === '/webhook/asaas')  return await handleWebhook(request, env);

      const m = path.match(/^\/checkout\/([a-zA-Z0-9_]+)\/status$/);
      if (method === 'GET' && m) return await handleCheckoutStatus(m[1], url, env);

      if (path === '/webhook/asaas' && (method === 'GET' || method === 'HEAD')) return json({ ok: true });
    } catch (e) {
      console.error('[worker]', e && e.message);
      return json({ error: 'Serviço temporariamente indisponível' }, 503);
    }

    return json({ error: 'Not found' }, 404);
  },
};
