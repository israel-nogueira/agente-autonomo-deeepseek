-- schema.sql — rode UMA vez:  npx wrangler d1 execute <NOME_DO_BANCO> --remote --file=schema.sql
-- Tudo com IF NOT EXISTS: seguro de rodar sobre o banco que você já tem.

-- Já existe no seu banco (mantido aqui só como referência / ambiente novo)
CREATE TABLE IF NOT EXISTS licenses (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  activation_code   TEXT UNIQUE,
  fingerprint       TEXT,
  token             TEXT,
  status            TEXT NOT NULL DEFAULT 'pending',   -- pending | active | blocked
  activated_at      TEXT,
  last_validated_at TEXT
);

-- NOVO: teste grátis (1 por fingerprint)
CREATE TABLE IF NOT EXISTS trials (
  fingerprint TEXT PRIMARY KEY,
  token       TEXT NOT NULL UNIQUE,
  ip          TEXT,
  started_at  INTEGER NOT NULL,   -- epoch ms
  expires_at  INTEGER NOT NULL    -- epoch ms
);
CREATE INDEX IF NOT EXISTS idx_trials_ip ON trials (ip, started_at);

-- NOVO: cobranças PIX (Asaas)
CREATE TABLE IF NOT EXISTS payments (
  cobranca_id     TEXT PRIMARY KEY,   -- id do pagamento no Asaas (pay_xxx)
  fingerprint     TEXT NOT NULL,
  customer_id     TEXT,
  nome            TEXT,
  valor           REAL NOT NULL,
  status          TEXT NOT NULL DEFAULT 'PENDING',   -- PENDING | RECEIVED
  activation_code TEXT,
  created_at      INTEGER NOT NULL,
  paid_at         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_payments_fp ON payments (fingerprint, created_at);
