# Setup — Worker de licença (teste 7 dias + PIX Asaas)

## 1. Worker (pasta worker/)
1. Edite `wrangler.toml`: `database_name` e `database_id` do seu D1 (`npx wrangler d1 list`).
2. Banco: `npx wrangler d1 execute SEU_BANCO --remote --file=schema.sql`
   (cria `trials` e `payments`; `licenses` só é criada se não existir).
3. Secrets (um por vez):
   npx wrangler secret put ASAAS_KEY_SANDBOX
   npx wrangler secret put ASAAS_WEBHOOK_TOKEN_SANDBOX
   (e, para produção: ASAAS_KEY_PRODUCAO, ASAAS_WEBHOOK_TOKEN)
4. `npx wrangler deploy`
5. No painel do Asaas (sandbox) > Integrações > Webhooks:
   URL  https://deepseek.nogueira.workers.dev/webhook/asaas
   Token de autenticação = o mesmo valor de ASAAS_WEBHOOK_TOKEN_SANDBOX
   Eventos: PAYMENT_RECEIVED e PAYMENT_CONFIRMED

## 2. App (pasta app/) — copie por cima dos arquivos de mesmo caminho
agent/license.js, agent/licensegate.js, main.js, preload.js, renderer/app.js, renderer/index.html
O mock foi REMOVIDO (não existe mais o código "MOCK-...").

## 3. Produção
`ASAAS_SANDBOX = "false"` no wrangler.toml, e os secrets de produção.
