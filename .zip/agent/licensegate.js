// agent/licensegate.js
// Estado da licenca no app: validacao no boot, janela de tolerancia de 1 minuto,
// travamento e checkout. NAO depende de Electron: o main.js liga os callbacks.
//
// Fases:
//   checking -> validando a licenca (boot)
//   valid    -> liberado
//   grace    -> sem licenca valida; barra de 1 min correndo; pode usar o app
//   locked   -> tolerancia esgotada; agent:run bloqueado; modal forcado
// Fechar o modal estando 'locked' abre uma nova tolerancia de 1 minuto.

const license = require('./license');

const GRACE_MS = 60 * 1000;
const RETRY_MS = 30 * 1000;

let cb = { onState: null, onLock: null };
let phase = 'checking';
let reason = null;          // 'no_license' | 'invalid' | 'offline' | null
let message = '';
let deadline = 0;
let showModal = false;
let lockTimer = null;
let retryTimer = null;
let activating = false;
let bootStarted = false;

function snapshot() {
    return {
        phase: phase,
        reason: reason,
        message: message,
        showModal: showModal,
        graceMs: GRACE_MS,
        remainingMs: phase === 'grace' ? Math.max(0, deadline - Date.now()) : 0,
        minValue: license.MIN_VALUE,
    };
}

function emit() {
    if (!cb.onState) return;
    try { cb.onState(snapshot()); } catch (e) { /* ignora */ }
}

function clearTimers() {
    if (lockTimer) { clearTimeout(lockTimer); lockTimer = null; }
    if (retryTimer) { clearInterval(retryTimer); retryTimer = null; }
}

function init(opts) {
    opts = opts || {};
    cb.onState = opts.onState || null;
    cb.onLock = opts.onLock || null;
    license.init(opts.userDataDir);
}

function setValid() {
    clearTimers();
    phase = 'valid';
    reason = null;
    message = '';
    deadline = 0;
    showModal = false;
    emit();
}

function lock() {
    lockTimer = null;
    if (phase !== 'grace') return;
    phase = 'locked';
    showModal = true;
    deadline = 0;
    emit();
    if (cb.onLock) {
        try { cb.onLock(); } catch (e) { /* ignora */ }
    }
}

function startGrace(withModal) {
    if (lockTimer) clearTimeout(lockTimer);
    phase = 'grace';
    showModal = !!withModal;
    deadline = Date.now() + GRACE_MS;
    lockTimer = setTimeout(lock, GRACE_MS);
    emit();
}

function startRetry() {
    if (retryTimer) return;
    retryTimer = setInterval(async () => {
        try {
            const r = await license.validate();
            if (r.status === 'valid') setValid();
        } catch (e) { /* tenta de novo */ }
    }, RETRY_MS);
}

function applyValidation(r) {
    if (r.status === 'valid') return setValid();

    reason = r.status === 'offline' ? 'offline' : (r.status === 'invalid' ? 'invalid' : 'no_license');
    message = r.error || '';
    startGrace(false);
    if (reason === 'offline') startRetry();
}

// ------------------------------------------------------------
// API
// ------------------------------------------------------------
async function boot() {
    if (bootStarted) return;
    bootStarted = true;
    phase = 'checking';
    emit();
    let r;
    try {
        r = await license.validate();
    } catch (e) {
        r = { status: 'offline' };
    }
    applyValidation(r);
}

function getState() {
    return snapshot();
}

// { ok: true } | { ok: false, error }
function allowRun() {
    if (phase === 'valid' || phase === 'grace') return { ok: true };
    if (phase === 'checking') return { ok: false, error: 'Validando a licença… tente novamente em instantes.' };
    return { ok: false, error: 'Licença necessária para executar tarefas.' };
}

function open() {
    if (phase === 'valid' || phase === 'checking') return;
    showModal = true;
    emit();
}

function dismiss() {
    if (phase === 'locked') return startGrace(false);
    if (phase === 'grace') {
        showModal = false;
        emit();
    }
}

async function startCheckout(valor) {
    if (phase === 'valid') return { ok: false, error: 'Este app já está licenciado.' };
    return license.createCheckout(valor);
}

// Consulta o pagamento. Quando confirmado, ativa e libera o app sozinho.
// Retorna { status: 'PENDING' | 'NOT_FOUND' | 'ERROR', error? } ou { status: 'RECEIVED', unlocked: true }
async function pollCheckout(cobrancaId) {
    if (activating) return { status: 'PENDING' };
    const s = await license.checkoutStatus(cobrancaId);
    if (s.status !== 'RECEIVED' || !s.activation_code) return s;

    activating = true;
    try {
        const a = await license.activate(s.activation_code);
        if (!a.ok) return { status: 'ERROR', error: a.error };
        const v = await license.validate();
        if (v.status !== 'valid') return { status: 'ERROR', error: v.error || 'Não foi possível validar a licença.' };
        setValid();
        return { status: 'RECEIVED', unlocked: true };
    } finally {
        activating = false;
    }
}

// Ativacao manual por codigo. { ok: true } | { ok: false, error }
async function activateCode(code) {
    if (activating) return { ok: false, error: 'Ativação em andamento.' };
    activating = true;
    try {
        const a = await license.activate(code);
        if (!a.ok) return a;
        const v = await license.validate();
        if (v.status !== 'valid') return { ok: false, error: v.error || 'Não foi possível validar a licença.' };
        setValid();
        return { ok: true };
    } finally {
        activating = false;
    }
}

function stop() {
    clearTimers();
}

module.exports = { init, boot, getState, allowRun, open, dismiss, startCheckout, pollCheckout, activateCode, stop };