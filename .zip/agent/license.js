// agent/license.js
// Licenciamento: fingerprint do PC + ativacao + validacao contra o Worker.
// Este modulo NAO depende de Electron: recebe o diretorio userData em init().
// Persiste o token em <userData>/license.json (escrita atomica .tmp + rename).

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const API_URL = 'https://deepseek.nogueira.workers.dev';
const REQUEST_TIMEOUT_MS = 8000;
const EXEC_TIMEOUT_MS = 8000;

// ------------------------------------------------------------
// MOCK: enquanto o Worker de pagamento nao existe (so para montar a experiencia).
// Trocar MOCK para false quando /checkout e /checkout/:id/status estiverem no ar.
// ------------------------------------------------------------
const MOCK = true;
const MOCK_OFFLINE = false;        // true = simula servidor fora do ar no validate()
const MOCK_PAY_AFTER_MS = 10000;   // tempo ate o "PIX" ser dado como pago
const MIN_VALUE = 15;              // valor minimo da ajuda (R$)
const mockCheckouts = new Map();   // cobranca_id -> timestamp de criacao

let DATA_DIR = null;

function init(userDataDir) {
    DATA_DIR = userDataDir;
}

function licensePath() {
    if (!DATA_DIR) throw new Error('license.init() nao foi chamado');
    return path.join(DATA_DIR, 'license.json');
}

// ------------------------------------------------------------
// Execucao de comando (async, sem janela, com timeout). Retorna '' se falhar.
// ------------------------------------------------------------
function run(cmd, args) {
    return new Promise((resolve) => {
        try {
            execFile(cmd, args, { timeout: EXEC_TIMEOUT_MS, windowsHide: true }, (err, stdout) => {
                if (err) return resolve('');
                resolve(String(stdout || ''));
            });
        } catch (e) {
            resolve('');
        }
    });
}

function clean(value) {
    return String(value || '').replace(/[^A-Za-z0-9]/g, '').toLowerCase();
}

// ------------------------------------------------------------
// Componentes do fingerprint
// ------------------------------------------------------------
function getCpu() {
    try {
        const cpus = os.cpus();
        return cpus && cpus[0] ? String(cpus[0].model).trim() : '';
    } catch (e) {
        return '';
    }
}

async function getMachineId() {
    if (process.platform === 'win32') {
        const out = await run('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid']);
        const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
        return m ? m[1].trim() : '';
    }
    if (process.platform === 'linux') {
        for (const f of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
            try {
                const v = fs.readFileSync(f, 'utf8').trim();
                if (v) return v;
            } catch (e) { /* tenta o proximo */ }
        }
        return '';
    }
    if (process.platform === 'darwin') {
        const out = await run('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice']);
        const m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/);
        return m ? m[1].trim() : '';
    }
    return '';
}

async function getDiskSerial() {
    if (process.platform === 'win32') {
        const out = await run('powershell.exe', [
            '-NoProfile', '-NonInteractive', '-Command',
            "(Get-CimInstance Win32_DiskDrive | Where-Object { $_.Index -eq 0 }).SerialNumber",
        ]);
        return out.trim();
    }
    if (process.platform === 'linux') {
        const out = await run('lsblk', ['-dno', 'SERIAL']);
        const first = out.split(/\r?\n/).map(s => s.trim()).find(Boolean);
        return first || '';
    }
    if (process.platform === 'darwin') {
        const out = await run('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice']);
        const m = out.match(/"IOPlatformSerialNumber"\s*=\s*"([^"]+)"/);
        return m ? m[1].trim() : '';
    }
    return '';
}

// ------------------------------------------------------------
// Fingerprint: sha256(CPU | ID da maquina (OS) | serial do disco | plataforma-arch)
// ------------------------------------------------------------
async function getFingerprint() {
    const [machineId, disk] = await Promise.all([getMachineId(), getDiskSerial()]);
    const raw = [
        clean(getCpu()),
        clean(machineId),
        clean(disk),
        process.platform + '-' + process.arch,
    ].join('|');
    return crypto.createHash('sha256').update(raw).digest('hex');
}

// ------------------------------------------------------------
// Armazenamento do token
// ------------------------------------------------------------
function readStored() {
    try {
        const data = JSON.parse(fs.readFileSync(licensePath(), 'utf8'));
        if (data && typeof data.token === 'string' && data.token) return data;
    } catch (e) { /* sem licenca salva */ }
    return null;
}

function writeStored(token) {
    const file = licensePath();
    const tmp = file + '.tmp';
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(tmp, JSON.stringify({ token: token, saved_at: new Date().toISOString() }), 'utf8');
    fs.renameSync(tmp, file);
}

function clear() {
    try { fs.unlinkSync(licensePath()); } catch (e) { /* ignora */ }
}

// ------------------------------------------------------------
// HTTP. Retorna { status, body } ou { networkError: true }.
// ------------------------------------------------------------
async function post(route, payload) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
        const res = await fetch(API_URL + route, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: controller.signal,
        });
        let body = null;
        try { body = await res.json(); } catch (e) { body = null; }
        return { status: res.status, body: body };
    } catch (e) {
        return { networkError: true };
    } finally {
        clearTimeout(timer);
    }
}

// ------------------------------------------------------------
// Ativacao: codigo -> token salvo.
// Retorna { ok: true } | { ok: false, offline?: true, error }
// ------------------------------------------------------------
async function activate(activationCode) {
    const code = String(activationCode || '').trim();
    if (!code) return { ok: false, error: 'Informe o código de ativação' };

    if (MOCK && /^MOCK-/i.test(code)) {
        try {
            writeStored('mock-' + code);
        } catch (e) {
            return { ok: false, error: 'Falha ao salvar a licença: ' + e.message };
        }
        return { ok: true };
    }

    const fingerprint = await getFingerprint();
    const r = await post('/activate', { activation_code: code, fingerprint: fingerprint });

    if (r.networkError) return { ok: false, offline: true, error: 'Sem conexão com o servidor de licenças' };
    if (r.status >= 500) return { ok: false, offline: true, error: 'Servidor de licenças indisponível' };
    if (r.status === 200 && r.body && r.body.token) {
        try {
            writeStored(r.body.token);
        } catch (e) {
            return { ok: false, error: 'Falha ao salvar a licença: ' + e.message };
        }
        return { ok: true };
    }
    return { ok: false, error: (r.body && r.body.error) || 'Falha na ativação' };
}

// ------------------------------------------------------------
// Validacao: token salvo + fingerprint atual -> Worker.
// status: 'valid' | 'invalid' | 'offline' | 'no_license'
// 'invalid' apaga o token salvo (licenca bloqueada/outro dispositivo).
// ------------------------------------------------------------
async function validate() {
    const stored = readStored();
    if (!stored) return { status: 'no_license' };

    if (MOCK_OFFLINE) return { status: 'offline' };
    if (MOCK && stored.token.startsWith('mock-')) return { status: 'valid' };

    const fingerprint = await getFingerprint();
    const r = await post('/validate', { fingerprint: fingerprint, token: stored.token });

    if (r.networkError) return { status: 'offline' };
    if (r.status >= 500) return { status: 'offline' };
    if (r.status === 200 && r.body && r.body.valid === true) return { status: 'valid' };
    if (r.status === 403 || r.status === 400) {
        clear();
        return { status: 'invalid', error: (r.body && r.body.error) || 'Licença inválida' };
    }
    return { status: 'offline' };
}

// ------------------------------------------------------------
// QR fake (SVG) para o MOCK: 3 marcadores + celulas pseudo-aleatorias.
// ------------------------------------------------------------
function mockQrDataUri(seed) {
    const N = 25, S = 8, M = 1;
    const size = (N + M * 2) * S;
    let state = crypto.createHash('sha256').update(String(seed)).digest().readUInt32LE(0) || 1;
    const rand = () => {
        state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
        return state / 4294967296;
    };
    const inFinder = (x, y) => (x < 8 && y < 8) || (x >= N - 8 && y < 8) || (x < 8 && y >= N - 8);
    const rect = (x, y, w, fill) =>
        '<rect x="' + (x + M) * S + '" y="' + (y + M) * S + '" width="' + w * S + '" height="' + w * S + '" fill="' + fill + '"/>';

    let body = '';
    for (let y = 0; y < N; y++) {
        for (let x = 0; x < N; x++) {
            if (inFinder(x, y)) continue;
            if (rand() > 0.5) body += rect(x, y, 1, '#000');
        }
    }
    for (const [fx, fy] of [[0, 0], [N - 7, 0], [0, N - 7]]) {
        body += rect(fx, fy, 7, '#000') + rect(fx + 1, fy + 1, 5, '#fff') + rect(fx + 2, fy + 2, 3, '#000');
    }

    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size +
        '" viewBox="0 0 ' + size + ' ' + size + '"><rect width="100%" height="100%" fill="#fff"/>' + body + '</svg>';
    return 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');
}

// ------------------------------------------------------------
// Checkout: gera a cobranca PIX para o valor escolhido (minimo R$ 15).
// Retorna { ok: true, cobranca_id, valor, pix_qrcode (data URI), pix_copia_cola, expira_em }
//       | { ok: false, error }
// ------------------------------------------------------------
async function createCheckout(valor) {
    const v = Number(valor);
    if (!isFinite(v) || v < MIN_VALUE) {
        return { ok: false, error: 'O valor mínimo é R$ ' + MIN_VALUE + ',00' };
    }

    if (MOCK) {
        const id = 'mock_' + crypto.randomBytes(6).toString('hex');
        mockCheckouts.set(id, Date.now());
        return {
            ok: true,
            cobranca_id: id,
            valor: Math.round(v * 100) / 100,
            pix_qrcode: mockQrDataUri(id),
            pix_copia_cola: '00020126580014br.gov.bcb.pix0136mock-' + id + '5204000053039865802BR5909OPENDSEEK6009CURITIBA62070503***6304MOCK',
            expira_em: 15,
        };
    }

    return { ok: false, error: 'Checkout ainda não disponível' };
}

// ------------------------------------------------------------
// Status do pagamento (o modal consulta de tempos em tempos).
// status: 'PENDING' | 'RECEIVED' (com activation_code) | 'NOT_FOUND' | 'ERROR'
// ------------------------------------------------------------
async function checkoutStatus(cobrancaId) {
    if (MOCK) {
        const t = mockCheckouts.get(String(cobrancaId));
        if (!t) return { status: 'NOT_FOUND' };
        if (Date.now() - t >= MOCK_PAY_AFTER_MS) {
            return { status: 'RECEIVED', activation_code: 'MOCK-' + String(cobrancaId).slice(5).toUpperCase() };
        }
        return { status: 'PENDING' };
    }

    return { status: 'ERROR', error: 'Checkout ainda não disponível' };
}

module.exports = { init, getFingerprint, readStored, activate, validate, clear, createCheckout, checkoutStatus, MIN_VALUE };